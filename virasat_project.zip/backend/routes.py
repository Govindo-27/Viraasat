"""
Flask API routes blueprint for Virasat Cultural Heritage Archive.
"""
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify
from backend.storage import get_all_contributions, get_contribution_by_id, save_contribution
from backend.curator import VirasatHeritageCurator

api_bp = Blueprint("api", __name__, url_prefix="/api")
curator = VirasatHeritageCurator()


@api_bp.route("/status", methods=["GET"])
def get_status():
    """System health check and AI status."""
    info = curator.check_status()
    items = get_all_contributions()
    return jsonify({
        "status": "online",
        "archiveEntries": len(items),
        "storage": "JSON prototype (data/contributions.json)",
        "aiCurator": "Cloud AI Heritage Engine (Zero Setup Required)",
        "details": info,
    })


@api_bp.route("/contributions", methods=["GET"])
def list_contributions():
    """Retrieve saved tradition contributions with search and filter support."""
    q = request.args.get("q", "").strip().lower()
    category = request.args.get("category", "").strip()
    language = request.args.get("language", "").strip()

    items = get_all_contributions()

    if category and category != "All":
        items = [it for it in items if it.get("category", "").lower() == category.lower()]

    if language and language != "All":
        items = [it for it in items if language.lower() in it.get("language", "").lower()]

    if q:
        filtered = []
        for it in items:
            title_match = q in it.get("title", "").lower()
            text_match = q in it.get("originalText", "").lower()
            reg_match = q in it.get("region", "").lower()
            sum_match = q in it.get("curatorNotes", {}).get("summary", "").lower()
            tags_match = any(q in t.lower() for t in it.get("curatorNotes", {}).get("tags", []))
            trans_match = q in it.get("curatorNotes", {}).get("englishTranslation", "").lower()
            if title_match or text_match or reg_match or sum_match or tags_match or trans_match:
                filtered.append(it)
        items = filtered

    return jsonify({
        "success": True,
        "count": len(items),
        "data": items
    })


@api_bp.route("/contributions/<entry_id>", methods=["GET"])
def get_contribution(entry_id):
    """Retrieve a single tradition entry by ID."""
    item = get_contribution_by_id(entry_id)
    if not item:
        return jsonify({"success": False, "error": "Tradition not found"}), 404
    return jsonify({"success": True, "data": item})


@api_bp.route("/curate", methods=["POST"])
def curate_preview():
    """On-demand AI heritage curator for a tradition before saving."""
    data = request.get_json() or {}
    title = data.get("title", "").strip()
    original_text = data.get("originalText", "").strip()
    language = data.get("language", "Unknown").strip()
    category = data.get("category", "Stories").strip()
    region = data.get("region", "").strip()

    if not title or not original_text:
        return jsonify({"success": False, "error": "Title and original text are required."}), 400

    curation = curator.curate_tradition(
        title=title,
        original_text=original_text,
        language=language,
        category=category,
        region=region
    )

    curation["generatedAt"] = datetime.now(timezone.utc).isoformat()
    return jsonify({"success": True, "data": curation})


@api_bp.route("/contributions", methods=["POST"])
def create_contribution():
    """Validate and preserve a new tradition in the archive."""
    data = request.get_json() or {}
    title = data.get("title", "").strip()
    original_language = data.get("originalLanguage", "").strip()
    category = data.get("category", "").strip()
    region = data.get("region", "").strip()
    original_text = data.get("originalText", "").strip()
    contributor_name = data.get("contributorName", "").strip() or "Community Contributor"
    consent_given = data.get("consentGiven", False)
    curator_notes = data.get("curatorNotes")

    # Validation
    if len(title) < 3:
        return jsonify({"success": False, "error": "Title must be at least 3 characters."}), 400
    if not original_language:
        return jsonify({"success": False, "error": "Original language is required."}), 400
    if not category:
        return jsonify({"success": False, "error": "Category is required."}), 400
    if len(original_text) < 15:
        return jsonify({"success": False, "error": "Tradition text must be at least 15 characters."}), 400
    if not consent_given:
        return jsonify({"success": False, "error": "Consent acknowledgment is required to preserve traditions."}), 400

    if not curator_notes or not curator_notes.get("summary"):
        curator_notes = curator.curate_tradition(
            title=title,
            original_text=original_text,
            language=original_language,
            category=category,
            region=region
        )
        curator_notes["generatedAt"] = datetime.now(timezone.utc).isoformat()

    record = {
        "title": title,
        "category": category,
        "language": original_language,
        "region": region or "Unspecified Region",
        "contributorName": contributor_name,
        "datePreserved": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "originalText": original_text,
        "consentGiven": True,
        "verifiedStatus": "Unverified Community Contribution",
        "curatorNotes": curator_notes,
    }

    # Extract YouTube & Spotify links if supplied
    media_tutorial = data.get("mediaTutorial") or {}
    youtube_url = data.get("youtubeUrl", "").strip()
    spotify_url = data.get("spotifyUrl", "").strip()
    if youtube_url and not media_tutorial.get("youtube"):
        video_id = ""
        if "v=" in youtube_url:
            video_id = youtube_url.split("v=")[1].split("&")[0]
        elif "youtu.be/" in youtube_url:
            video_id = youtube_url.split("youtu.be/")[1].split("?")[0]
        media_tutorial["youtube"] = {
            "videoId": video_id,
            "url": youtube_url,
            "embedUrl": f"https://www.youtube.com/embed/{video_id}" if video_id else youtube_url,
            "title": f"{title} — Video Demonstration",
            "tutorialType": "Community Practice Demonstration"
        }
    if spotify_url and not media_tutorial.get("spotify"):
        track_id = ""
        if "track/" in spotify_url:
            track_id = spotify_url.split("track/")[1].split("?")[0]
        media_tutorial["spotify"] = {
            "trackId": track_id,
            "url": spotify_url,
            "embedUrl": f"https://open.spotify.com/embed/track/{track_id}" if track_id else spotify_url,
            "title": f"{title} — Acoustic Audio Stream",
            "artist": contributor_name
        }
    if media_tutorial:
        record["mediaTutorial"] = media_tutorial

    saved = save_contribution(record)
    return jsonify({"success": True, "data": saved}), 201


@api_bp.route("/ask", methods=["POST"])
def ask_archive():
    """Ask questions strictly grounded in saved traditions."""
    data = request.get_json() or {}
    question = data.get("question", "").strip()

    if not question:
        return jsonify({"success": False, "error": "A question is required."}), 400

    items = get_all_contributions()
    answer, cited, model_used = curator.ask_archive(question, items)

    return jsonify({
        "success": True,
        "answer": answer,
        "citedEntries": cited,
        "modelUsed": model_used,
        "archiveEntriesCount": len(items)
    })


# ============================================================
# Voice & Regional Audio Narration Endpoints
# ============================================================
import os
import json
import hashlib
import math
import struct
from flask import Response, send_file

REGIONAL_LANGUAGES = [
    {"id": "hindi", "name": "Hindi", "nativeName": "हिन्दी", "flag": "🇮🇳", "description": "मानक वाचिक स्वर (राष्ट्रीय मानक)"},
    {"id": "bhojpuri", "name": "Bhojpuri", "nativeName": "भोजपुरी", "flag": "🌾", "description": "भोजपुरिया लोक-कंठ (बिहार / पूर्वी उप)"},
    {"id": "kashmiri", "name": "Kashmiri", "nativeName": "कॉशुर (كٲशُر)", "flag": "🏔️", "description": "कश्मीरी वादीक बोली (कश्मीर घाटी)"},
    {"id": "nagpuri", "name": "Nagpuri", "nativeName": "नागपुरी / सादरी", "flag": "🌿", "description": "छोटानागपुरिया सादरी (झारखंड)"},
    {"id": "english", "name": "English", "nativeName": "English", "flag": "🌐", "description": "Scholarly Archival Narration"},
    {"id": "maithili", "name": "Maithili", "nativeName": "मैथिली", "flag": "📜", "description": "मिथिलांचल भाषा (जनकपुर / तिरहुत)"},
    {"id": "awadhi", "name": "Awadhi", "nativeName": "अवधी", "flag": "🪔", "description": "अवध लोक शैली (अयोध्या / अवध)"},
    {"id": "bengali", "name": "Bengali", "nativeName": "বাংলা", "flag": "🌊", "description": "ঐতিহ্যবাহী বাংলা (पश्चिमবঙ্গ)"},
]

ELEVENLABS_VOICES = [
    {"id": "21m00Tcm4TlvDq8ikWAM", "name": "Rachel (Oral Storyteller)", "gender": "Female", "description": "Warm, natural cadence, ideal for living traditions & oral history"},
    {"id": "ErXwobaYiN019PkySvjV", "name": "Antoni (Chronicler)", "gender": "Male", "description": "Resonant, scholarly, and clear for archival recitations"},
    {"id": "EXAVITQu4vr4xnSDxMaL", "name": "Bella (Folk Voice)", "gender": "Female", "description": "Expressive and evocative for rituals, chants, and songs"},
    {"id": "onwK4e9ZLuTAKqWW03F9", "name": "Daniel (Archivist)", "gender": "Male", "description": "Authoritative documentary voice for historical preservation"},
]

def load_regional_translations():
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "regional-translations.json")
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print("Error loading regional translations:", e)
    return {}

def generate_procedural_tanpura_wav(duration_sec=3.5, sample_rate=24000):
    num_samples = int(duration_sec * sample_rate)
    data_size = num_samples * 2
    header = bytearray()
    header.extend(b"RIFF")
    header.extend(struct.pack("<I", 36 + data_size))
    header.extend(b"WAVE")
    header.extend(b"fmt ")
    header.extend(struct.pack("<I", 16))
    header.extend(struct.pack("<H", 1)) # PCM
    header.extend(struct.pack("<H", 1)) # Mono
    header.extend(struct.pack("<I", sample_rate))
    header.extend(struct.pack("<I", sample_rate * 2))
    header.extend(struct.pack("<H", 2))
    header.extend(struct.pack("<H", 16))
    header.extend(b"data")
    header.extend(struct.pack("<I", data_size))

    notes = [146.83, 220.0, 293.66, 369.99]
    pcm = bytearray()
    for i in range(num_samples):
        t = i / sample_rate
        val = 0.0
        for idx, freq in enumerate(notes):
            decay = math.exp(-t * (0.7 + idx * 0.25))
            val += math.sin(2 * math.pi * freq * t) * decay * 0.20
        ival = max(-32767, min(32767, int(val * 32767)))
        pcm.extend(struct.pack("<h", ival))
    return bytes(header + pcm)


@api_bp.route("/voice/info", methods=["GET"])
def get_voice_info():
    """Return available narrators and configuration."""
    return jsonify({
        "elevenlabsConfigured": bool(os.environ.get("ELEVENLABS_API_KEY")),
        "neuralConfigured": True,
        "defaultVoice": "21m00Tcm4TlvDq8ikWAM",
        "voices": ELEVENLABS_VOICES,
    })


@api_bp.route("/voice/regional-languages", methods=["GET"])
def get_regional_languages():
    """Return list of supported Indian regional languages."""
    return jsonify({
        "success": True,
        "languages": REGIONAL_LANGUAGES,
    })


@api_bp.route("/voice/regional-narration", methods=["GET"])
def get_regional_narration():
    """Return localized caption and oral narration for a tradition."""
    tradition_id = request.args.get("id", "").strip()
    lang = (request.args.get("lang") or "hindi").lower().strip()

    if not tradition_id:
        return jsonify({"success": False, "error": "Tradition ID is required"}), 400

    translations = load_regional_translations()
    trad_translations = translations.get(tradition_id, {})

    lang_obj = next((l for l in REGIONAL_LANGUAGES if l["id"] == lang), None)
    if not lang_obj:
        lang_obj = {"id": lang, "name": lang.capitalize(), "nativeName": lang, "flag": "🗣️"}

    entry = trad_translations.get(lang)
    if not entry:
        # Fallback to tradition original text
        trad = get_contribution_by_id(tradition_id)
        if trad:
            caption = trad.get("curatorNotes", {}).get("summary") or trad.get("title", "")
            description = trad.get("curatorNotes", {}).get("englishTranslation") or trad.get("originalText", "")
            entry = {
                "language": lang_obj["name"],
                "nativeName": lang_obj["nativeName"],
                "flag": lang_obj["flag"],
                "caption": caption,
                "description": description,
            }
        else:
            return jsonify({"success": False, "error": "Tradition not found"}), 404

    caption = entry.get("caption", "")
    description = entry.get("description", "")
    full_text = f"{caption} {description}".strip()

    return jsonify({
        "success": True,
        "traditionId": tradition_id,
        "langId": lang,
        "language": entry.get("language", lang_obj["name"]),
        "nativeName": entry.get("nativeName", lang_obj["nativeName"]),
        "flag": entry.get("flag", lang_obj["flag"]),
        "caption": caption,
        "description": description,
        "fullText": full_text,
        "audioUrls": {
            "all": f"/api/voice/regional-audio?id={tradition_id}&lang={lang}&part=all",
            "caption": f"/api/voice/regional-audio?id={tradition_id}&lang={lang}&part=caption",
            "description": f"/api/voice/regional-audio?id={tradition_id}&lang={lang}&part=description",
        }
    })


@api_bp.route("/voice/regional-audio", methods=["GET"])
def get_regional_audio():
    """Stream or serve regional audio narration."""
    tradition_id = request.args.get("id", "").strip()
    lang = (request.args.get("lang") or "hindi").lower().strip()
    part = (request.args.get("part") or "all").lower().strip()
    voice_id = request.args.get("voiceId") or "21m00Tcm4TlvDq8ikWAM"

    audio_cache_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "audio-cache")

    # Check cached files
    if os.path.exists(audio_cache_dir):
        translations = load_regional_translations()
        entry = translations.get(tradition_id, {}).get(lang, {})
        target_text = entry.get("caption" if part == "caption" else "description" if part == "description" else "description", "")
        if target_text:
            h1 = hashlib.sha256(f"v2_{voice_id}_{lang}_{target_text.strip()}".encode("utf-8")).hexdigest()
            h2 = hashlib.sha256(f"{voice_id}_{lang}_{target_text.strip()}".encode("utf-8")).hexdigest()
            for h in [h1, h2]:
                mp3 = os.path.join(audio_cache_dir, f"{h}.mp3")
                wav = os.path.join(audio_cache_dir, f"{h}.wav")
                if os.path.exists(mp3):
                    return send_file(mp3, mimetype="audio/mpeg")
                if os.path.exists(wav):
                    return send_file(wav, mimetype="audio/wav")

    # Graceful fallback: return procedural tanpura chime
    wav_bytes = generate_procedural_tanpura_wav(3.5, 24000)
    return Response(wav_bytes, mimetype="audio/wav", headers={"Cache-Control": "public, max-age=86400"})


@api_bp.route("/voice/stream", methods=["GET"])
def get_voice_stream():
    """Stream narrative voice audio."""
    tradition_id = request.args.get("id", "").strip()
    voice_id = request.args.get("voiceId") or "21m00Tcm4TlvDq8ikWAM"
    audio_cache_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "audio-cache")

    # Check cache for any matching mp3/wav
    if os.path.exists(audio_cache_dir):
        trad = get_contribution_by_id(tradition_id)
        if trad:
            summary = trad.get("curatorNotes", {}).get("summary", "")
            h1 = hashlib.sha256(f"v2_{voice_id}_en_{summary.strip()}".encode("utf-8")).hexdigest()
            h2 = hashlib.sha256(f"{voice_id}_en_{summary.strip()}".encode("utf-8")).hexdigest()
            for h in [h1, h2]:
                mp3 = os.path.join(audio_cache_dir, f"{h}.mp3")
                wav = os.path.join(audio_cache_dir, f"{h}.wav")
                if os.path.exists(mp3):
                    return send_file(mp3, mimetype="audio/mpeg")
                if os.path.exists(wav):
                    return send_file(wav, mimetype="audio/wav")

    wav_bytes = generate_procedural_tanpura_wav(3.5, 24000)
    return Response(wav_bytes, mimetype="audio/wav", headers={"Cache-Control": "public, max-age=86400"})


@api_bp.route("/voice/synthesize", methods=["POST"])
def post_voice_synthesize():
    """Synthesize voice endpoint."""
    data = request.get_json() or {}
    tradition_id = data.get("traditionId", "")
    voice_id = data.get("voiceId", "21m00Tcm4TlvDq8ikWAM")
    return jsonify({
        "success": True,
        "engine": "speechSynthesis",
        "mimeType": "audio/wav",
        "streamUrl": f"/api/voice/stream?id={tradition_id}&voiceId={voice_id}"
    })
