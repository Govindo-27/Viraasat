import React, { useState } from "react";
import { Sparkles, Send, BookOpen, AlertCircle, HelpCircle, Volume2, Square } from "lucide-react";
import { Tradition } from "../types";

interface AskArchiveProps {
  traditions: Tradition[];
  onSelectTraditionById: (id: string) => void;
}

interface QnAResult {
  question: string;
  answer: string;
  citedEntries: string[];
  modelUsed: string;
  timestamp: string;
}

const SAMPLE_QUESTIONS = [
  "How do Kutch weavers measure wool tension using musical raga?",
  "What is the traditional river gauging ritual in the Kaveri Delta?",
  "Describe the sacred materials used for the Kumartuli censer dance.",
  "Which traditional recipes use fermented millet porridge?", // Tests non-present info!
];

export const AskArchive: React.FC<AskArchiveProps> = ({
  traditions,
  onSelectTraditionById,
}) => {
  const [question, setQuestion] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<QnAResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [speakingIdx, setSpeakingIdx] = useState<number | null>(null);

  const handleAsk = async (queryText?: string) => {
    const q = (queryText || question).trim();
    if (!q) return;

    setError(null);
    setIsLoading(true);
    setQuestion(q);

    try {
      const response = await fetch("/api/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: q }),
      });

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to query the archive.");
      }

      const newResult: QnAResult = {
        question: q,
        answer: data.answer,
        citedEntries: data.citedEntries || [],
        modelUsed: data.modelUsed || "Virasat AI Heritage Curator",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setHistory((prev) => [newResult, ...prev]);
      setQuestion("");
    } catch (err: any) {
      setError(err.message || "Archive query encountered an error.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSpeak = (idx: number, text: string) => {
    if (!("speechSynthesis" in window)) {
      alert("Audio narration is not supported in this browser.");
      return;
    }

    if (speakingIdx === idx) {
      window.speechSynthesis.cancel();
      setSpeakingIdx(null);
      return;
    }

    window.speechSynthesis.cancel();
    const clean = text.replace(/\*\*|\*|##|__|```/g, "").trim();
    const utterance = new SpeechSynthesisUtterance(clean);
    
    // Natural human speech speed (1.0x) and natural pitch
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      const naturalVoice = voices.find(
        (v) =>
          (v.lang.startsWith("en") || v.lang === "en-IN") &&
          (v.name.includes("Natural") || v.name.includes("Google") || v.name.includes("Neerja") || v.name.includes("Prabhat") || v.name.includes("Jenny"))
      );
      if (naturalVoice) {
        utterance.voice = naturalVoice;
      }
    }

    utterance.onend = () => setSpeakingIdx(null);
    utterance.onerror = () => setSpeakingIdx(null);

    setSpeakingIdx(idx);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-left">
      {/* Section Header */}
      <div className="pb-6 border-b border-[#E5DDD0]">
        <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
          <Sparkles size={14} />
          <span>Curatorial Query Engine</span>
        </div>
        <h2 className="text-3xl font-serif font-bold text-[#1B4332] mt-1.5">
          Ask the Virasat Archive
        </h2>
        <p className="text-sm text-[#6B655B] mt-1.5 max-w-2xl leading-relaxed">
          Ask questions about our preserved traditions. In accordance with strict archival rigor, the
          curator answers solely using documented community contributions, cites accession entries,
          and explicitly states when information is not present in our records.
        </p>
      </div>

      {/* Suggested Inquiries */}
      <div className="mt-6">
        <div className="text-xs font-semibold uppercase tracking-wider text-[#8B8477] mb-2 flex items-center gap-1.5">
          <HelpCircle size={13} />
          <span>Suggested Inquiries</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_QUESTIONS.map((sq, idx) => (
            <button
              key={idx}
              onClick={() => handleAsk(sq)}
              disabled={isLoading}
              className="text-xs bg-white border border-[#D5C9B7] text-[#443E36] hover:border-[#1B4332] hover:text-[#1B4332] hover:bg-[#FAF7F2] px-3 py-1.5 rounded-md text-left transition-colors cursor-pointer"
            >
              "{sq}"
            </button>
          ))}
        </div>
      </div>

      {/* Query Input Box */}
      <div className="mt-6">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleAsk();
          }}
          className="relative"
        >
          <textarea
            rows={3}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question about preserved traditions, folk practices, songs, or crafts (e.g. 'How is natural brown dye boiled in Kutch?')..."
            className="w-full px-4 py-3 bg-white border border-[#D5C9B7] rounded-lg text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332] font-serif leading-relaxed pr-24"
          />
          <button
            type="submit"
            disabled={isLoading || !question.trim()}
            className="absolute right-3 bottom-3 inline-flex items-center gap-1.5 px-4 py-2 bg-[#1B4332] text-white text-xs font-semibold rounded-md hover:bg-[#2D6A4F] disabled:opacity-50 transition-colors cursor-pointer shadow-xs"
          >
            {isLoading ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send size={13} />
            )}
            <span>Ask Curator</span>
          </button>
        </form>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mt-4 p-4 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 flex items-start gap-3">
          <AlertCircle size={18} className="text-rose-700 shrink-0 mt-0.5" />
          <div className="text-sm font-medium">{error}</div>
        </div>
      )}

      {/* Active Responses Stream */}
      <div className="mt-8 space-y-6">
        {isLoading && (
          <div className="p-6 bg-white border border-[#E5DDD0] rounded-lg text-center animate-pulse">
            <div className="w-6 h-6 border-2 border-[#1B4332] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs font-medium text-[#6B655B]">
              Consulting {traditions.length} archive entries...
            </p>
          </div>
        )}

        {history.map((item, idx) => (
          <article
            key={idx}
            className="bg-white border border-[#E5DDD0] rounded-lg p-6 shadow-xs text-left"
          >
            {/* Question Bar */}
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-[#F0EAE1]">
              <div className="text-sm font-semibold text-[#1B4332] font-serif">
                "{item.question}"
              </div>
              <div className="text-[11px] text-[#8B8477] shrink-0 font-mono">
                {item.timestamp}
              </div>
            </div>

            {/* Answer Body */}
            <div className="mt-4 text-sm text-[#22201D] leading-relaxed whitespace-pre-wrap font-serif">
              {item.answer}
            </div>

            {/* Source Citations & Audio Button */}
            <div className="mt-5 pt-3.5 border-t border-[#F0EAE1] flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[#8B8477] font-medium flex items-center gap-1">
                  <BookOpen size={13} />
                  Cited Sources:
                </span>
                {item.citedEntries.length > 0 ? (
                  item.citedEntries.map((cid) => (
                    <button
                      key={cid}
                      onClick={() => onSelectTraditionById(cid)}
                      className="inline-flex items-center gap-1 px-2 py-0.5 bg-[#FAF7F2] hover:bg-[#EFE9DF] border border-[#D5C9B7] rounded text-[11px] font-mono text-[#A64B2A] transition-colors cursor-pointer"
                      title="Inspect source record in archive"
                    >
                      <span>#{cid}</span>
                      <span aria-hidden="true">↗</span>
                    </button>
                  ))
                ) : (
                  <span className="text-[#8B8477] italic">No archive entries cited (out-of-scope question)</span>
                )}
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => toggleSpeak(idx, item.answer)}
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors cursor-pointer ${
                    speakingIdx === idx
                      ? "bg-[#1B4332] text-white"
                      : "text-[#6B655B] hover:text-[#1B4332] hover:bg-[#FAF7F2]"
                  }`}
                  title={speakingIdx === idx ? "Stop narration" : "Listen aloud to answer"}
                >
                  {speakingIdx === idx ? <Square size={12} /> : <Volume2 size={13} />}
                  <span>{speakingIdx === idx ? "Stop" : "Listen"}</span>
                </button>
                <span className="text-[11px] text-[#8B8477] font-mono">
                  {item.modelUsed}
                </span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};
