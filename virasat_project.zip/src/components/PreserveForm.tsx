import React, { useState } from "react";
import { Feather, Sparkles, AlertCircle, CheckCircle, ShieldCheck, Radio, Music } from "lucide-react";
import { HeritageCategory, CuratorNotes, Tradition, AudioSource } from "../types";
import { AudioPlayer, parseAudioSourceType } from "./AudioPlayer";

interface PreserveFormProps {
  onSuccess: (newTradition: Tradition) => void;
  onCancel: () => void;
}

const CATEGORIES: Exclude<HeritageCategory, "All">[] = [
  "Stories",
  "Recipes",
  "Folk Practices",
  "Festivals",
  "Traditional Crafts",
  "Oral Histories",
  "Music & Performing Arts",
];

const SUGGESTED_LANGUAGES = [
  "Hindi",
  "Bengali",
  "Tamil",
  "Telugu",
  "Marathi",
  "Gujarati",
  "Kachchhi",
  "Kannada",
  "Malayalam",
  "Punjabi",
  "Odia",
  "Assamese",
  "Bhojpuri",
  "Maithili",
  "Sanskrit",
  "Urdu",
  "English",
];

export const PreserveForm: React.FC<PreserveFormProps> = ({ onSuccess, onCancel }) => {
  const [title, setTitle] = useState("");
  const [originalLanguage, setOriginalLanguage] = useState("Hindi");
  const [customLanguage, setCustomLanguage] = useState("");
  const [category, setCategory] = useState<Exclude<HeritageCategory, "All">>("Oral Histories");
  const [region, setRegion] = useState("");
  const [contributorName, setContributorName] = useState("");
  const [originalText, setOriginalText] = useState("");
  const [consentGiven, setConsentGiven] = useState(false);

  // Audio Recording State (YouTube, Spotify, Internet Archive, or direct link)
  const [audioUrl, setAudioUrl] = useState("");
  const [audioTitle, setAudioTitle] = useState("");
  const [audioAttribution, setAudioAttribution] = useState("");

  // AI Curator State
  const [isCurating, setIsCurating] = useState(false);
  const [curatorNotes, setCuratorNotes] = useState<CuratorNotes | null>(null);
  const [curatorError, setCuratorError] = useState<string | null>(null);

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const effectiveLanguage = originalLanguage === "Other" ? customLanguage : originalLanguage;

  const handleRequestCurator = async () => {
    setValidationError(null);
    setCuratorError(null);

    if (!title.trim()) {
      setValidationError("Please enter a title before requesting AI curation.");
      return;
    }
    if (!originalText.trim() || originalText.trim().length < 15) {
      setValidationError("Please provide at least 15 characters of the tradition text before requesting AI curation.");
      return;
    }

    setIsCurating(true);
    try {
      const response = await fetch("/api/curate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          originalText: originalText.trim(),
          language: effectiveLanguage || "Unknown",
          category: category,
          region: region.trim(),
        }),
      });

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || "Failed to generate AI curation.");
      }

      setCuratorNotes(result.data);
    } catch (err: any) {
      setCuratorError(err.message || "Failed to connect to AI curator.");
    } finally {
      setIsCurating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!title.trim() || title.trim().length < 3) {
      setValidationError("Tradition title must be at least 3 characters long.");
      return;
    }
    if (!effectiveLanguage.trim()) {
      setValidationError("Please specify the original language of the tradition.");
      return;
    }
    if (!originalText.trim() || originalText.trim().length < 15) {
      setValidationError("Please write or paste at least 15 characters describing the tradition or oral history.");
      return;
    }
    if (!consentGiven) {
      setValidationError("You must confirm community consent and acknowledge archival fair use to submit.");
      return;
    }

    setIsSubmitting(true);
    try {
      let audioSourcePayload: AudioSource | undefined = undefined;
      if (audioUrl.trim()) {
        const parsed = parseAudioSourceType(audioUrl.trim());
        audioSourcePayload = {
          type: parsed.type,
          url: audioUrl.trim(),
          title: audioTitle.trim() || undefined,
          attribution: audioAttribution.trim() || undefined,
        };
      }

      const response = await fetch("/api/contributions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          originalLanguage: effectiveLanguage.trim(),
          category: category,
          region: region.trim() || "Unspecified Region",
          contributorName: contributorName.trim() || "Community Custodian",
          originalText: originalText.trim(),
          consentGiven: true,
          curatorNotes: curatorNotes,
          audioSource: audioSourcePayload,
        }),
      });

      const resData = await response.json();
      if (!resData.success) {
        throw new Error(resData.error || "Failed to preserve tradition.");
      }

      setSubmittedSuccess(true);
      setTimeout(() => {
        onSuccess(resData.data);
      }, 1200);
    } catch (err: any) {
      setValidationError(err.message || "An unexpected error occurred while saving.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-left">
      {/* Header */}
      <div className="pb-6 border-b border-[#E5DDD0]">
        <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
          <Feather size={14} />
          <span>Preservation Protocol</span>
        </div>
        <h2 className="text-3xl font-serif font-bold text-[#1B4332] mt-1.5">
          Preserve a Living Tradition
        </h2>
        <p className="text-sm text-[#6B655B] mt-1.5 max-w-2xl leading-relaxed">
          Record oral narratives, ancestral techniques, medicinal recipes, or sacred songs before
          they fade. We preserve your original tongue verbatim and generate scholarly synopses and
          faithful English translations for open cultural preservation.
        </p>
      </div>

      {/* Success Notification */}
      {submittedSuccess && (
        <div className="my-6 p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-center gap-3">
          <CheckCircle size={20} className="text-emerald-700 shrink-0" />
          <div className="text-sm font-medium">
            Tradition successfully deposited into the Virasat cultural repository! Redirecting to archive...
          </div>
        </div>
      )}

      {/* Validation Error Banner */}
      {validationError && (
        <div className="my-6 p-4 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 flex items-start gap-3">
          <AlertCircle size={18} className="text-rose-700 shrink-0 mt-0.5" />
          <div className="text-sm font-medium">{validationError}</div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        {/* Title */}
        <div>
          <label htmlFor="tradition-title" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1.5">
            Title of the Tradition or Oral Account <span className="text-[#A64B2A]">*</span>
          </label>
          <input
            id="tradition-title"
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., The Monsoon Wool Mnemonic of Bhujodi, or Sacred Turmeric Fermentation of Kolhapur"
            className="w-full px-3.5 py-2.5 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332]"
          />
        </div>

        {/* Row: Category & Language */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="tradition-category" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1.5">
              Cultural Domain / Category <span className="text-[#A64B2A]">*</span>
            </label>
            <select
              id="tradition-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full px-3.5 py-2.5 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332] cursor-pointer"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="tradition-lang" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1.5">
              Original Language / Dialect <span className="text-[#A64B2A]">*</span>
            </label>
            <select
              id="tradition-lang"
              value={originalLanguage}
              onChange={(e) => setOriginalLanguage(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332] cursor-pointer"
            >
              {SUGGESTED_LANGUAGES.map((lang) => (
                <option key={lang} value={lang}>
                  {lang}
                </option>
              ))}
              <option value="Other">Other / Regional Dialect</option>
            </select>
            {originalLanguage === "Other" && (
              <input
                type="text"
                value={customLanguage}
                onChange={(e) => setCustomLanguage(e.target.value)}
                placeholder="Specify regional dialect or mother tongue"
                className="mt-2 w-full px-3.5 py-2 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D]"
              />
            )}
          </div>
        </div>

        {/* Row: Region & Contributor */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="tradition-region" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1.5">
              Geographic Region / Village / Community (Optional)
            </label>
            <input
              id="tradition-region"
              type="text"
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              placeholder="e.g., Thanjavur Delta, Tamil Nadu, or Spiti Valley, Himachal"
              className="w-full px-3.5 py-2.5 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332]"
            />
          </div>

          <div>
            <label htmlFor="contributor-name" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1.5">
              Contributor or Storyteller Name (Optional)
            </label>
            <input
              id="contributor-name"
              type="text"
              value={contributorName}
              onChange={(e) => setContributorName(e.target.value)}
              placeholder="e.g., Elder Somnath, or leave blank for Anonymous"
              className="w-full px-3.5 py-2.5 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332]"
            />
          </div>
        </div>

        {/* Original Story / Tradition Text */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label htmlFor="tradition-text" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D]">
              Tradition Narrative / Recipe / Oral Song / Craft Steps <span className="text-[#A64B2A]">*</span>
            </label>
            <span className="text-xs text-[#8B8477] tabular-nums">
              {originalText.length} characters (min 15)
            </span>
          </div>
          <textarea
            id="tradition-text"
            rows={6}
            required
            value={originalText}
            onChange={(e) => setOriginalText(e.target.value)}
            placeholder="Document the tradition in its original tongue, script, or Romanized transliteration. Describe how it is practiced, words spoken, ingredients or materials used, and why it matters to the community..."
            className="w-full px-3.5 py-3 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332] font-serif leading-relaxed"
          />
          <p className="mt-1 text-xs text-[#6B655B]">
            Original text is permanently archived without alteration.
          </p>
        </div>

        {/* AI Heritage Curator Preview Box */}
        <div className="p-5 rounded-lg bg-white border border-[#E5DDD0]">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F0EAE1]">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#A64B2A]">
                <Sparkles size={14} />
                <span>AI Heritage Curator</span>
              </div>
              <p className="text-xs text-[#6B655B] mt-0.5">
                Generate curatorial summary, tags, and English translation before finalizing.
              </p>
            </div>
            <button
              type="button"
              onClick={handleRequestCurator}
              disabled={isCurating || !title.trim() || originalText.trim().length < 15}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-md bg-[#FAF7F2] border border-[#D5C9B7] text-[#1B4332] hover:bg-[#EFE9DF] disabled:opacity-50 transition-colors cursor-pointer shrink-0"
            >
              {isCurating ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-[#1B4332] border-t-transparent rounded-full animate-spin" />
                  <span>Curating...</span>
                </>
              ) : (
                <>
                  <Sparkles size={13} className="text-[#A64B2A]" />
                  <span>Preview AI Curation</span>
                </>
              )}
            </button>
          </div>

          {curatorError && (
            <div className="mt-3 text-xs text-rose-700 bg-rose-50 p-3 rounded border border-rose-200">
              {curatorError}
            </div>
          )}

          {curatorNotes && (
            <div className="mt-4 space-y-3.5 text-xs">
              <div className="p-3 bg-[#FAF7F2] rounded border border-[#E5DDD0]">
                <span className="font-semibold text-[#1B4332] block mb-1">
                  Curatorial Summary (Unverified AI Analysis):
                </span>
                <p className="text-[#332E27] leading-relaxed">{curatorNotes.summary}</p>
              </div>

              {curatorNotes.englishTranslation && (
                <div className="p-3 bg-[#FAF7F2] rounded border border-[#E5DDD0]">
                  <span className="font-semibold text-[#A64B2A] block mb-1">
                    English Translation:
                  </span>
                  <p className="text-[#332E27] leading-relaxed font-serif">
                    {curatorNotes.englishTranslation}
                  </p>
                </div>
              )}

              {curatorNotes.tags && curatorNotes.tags.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5 text-[#6B655B]">
                  <span className="font-semibold text-[#8B8477]">Generated Tags:</span>
                  {curatorNotes.tags.map((t) => (
                    <span key={t} className="bg-[#FAF7F2] border border-[#E5DDD0] px-2 py-0.5 rounded text-[11px]">
                      #{t}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Authentic Field Recording / Original Audio (Legal Source) */}
        <div className="p-5 rounded-lg bg-white border border-[#E5DDD0] space-y-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#1B4332]">
              <Radio size={14} className="text-[#A64B2A]" />
              <span>Attach Authentic Living Audio Recording (Optional)</span>
            </div>
            <p className="text-xs text-[#6B655B] mt-0.5">
              Preserve original voices, instruments, chants, or dialects from legal platforms (YouTube, Spotify, Internet Archive, or direct MP3/WAV links).
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <label htmlFor="audio-url" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1">
                Audio or Video URL (YouTube, Spotify, Archive.org, or Direct Audio)
              </label>
              <input
                id="audio-url"
                type="url"
                value={audioUrl}
                onChange={(e) => setAudioUrl(e.target.value)}
                placeholder="e.g. https://www.youtube.com/watch?v=... or https://open.spotify.com/track/..."
                className="w-full px-3.5 py-2.5 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332]"
              />
              <span className="text-[11px] text-[#8B8477] mt-1 block">
                Supports YouTube videos/shorts, Spotify tracks/episodes, Internet Archive audio recordings, and direct .mp3/.wav streams.
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="audio-title" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1">
                  Recording / Track Title (Optional)
                </label>
                <input
                  id="audio-title"
                  type="text"
                  value={audioTitle}
                  onChange={(e) => setAudioTitle(e.target.value)}
                  placeholder="e.g. Monsoon Raga Performance or Kaveri Invocation"
                  className="w-full px-3.5 py-2 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332]"
                />
              </div>

              <div>
                <label htmlFor="audio-attribution" className="block text-xs font-semibold uppercase tracking-wider text-[#22201D] mb-1">
                  Performer, Singer, or Archive Attribution (Optional)
                </label>
                <input
                  id="audio-attribution"
                  type="text"
                  value={audioAttribution}
                  onChange={(e) => setAudioAttribution(e.target.value)}
                  placeholder="e.g. Traditional Baul Troupe / Folk Archive"
                  className="w-full px-3.5 py-2 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] focus:outline-none focus:ring-1 focus:ring-[#1B4332]"
                />
              </div>
            </div>

            {/* Live Audio Preview when URL provided */}
            {audioUrl.trim().length > 5 && (
              <div className="pt-2">
                <div className="text-xs font-medium text-[#1B4332] mb-1.5 flex items-center gap-1">
                  <Music size={13} className="text-[#A64B2A]" />
                  <span>Audio Player Preview:</span>
                </div>
                <AudioPlayer
                  audioSource={{
                    type: parseAudioSourceType(audioUrl.trim()).type,
                    url: audioUrl.trim(),
                    title: audioTitle.trim() || undefined,
                    attribution: audioAttribution.trim() || undefined,
                  }}
                />
              </div>
            )}
          </div>
        </div>

        {/* Clear Consent Notice */}
        <div className="p-4 rounded-lg bg-[#F4EFE6] border border-[#D5C9B7]">
          <div className="flex items-start gap-3">
            <input
              id="consent-checkbox"
              type="checkbox"
              required
              checked={consentGiven}
              onChange={(e) => setConsentGiven(e.target.checked)}
              className="mt-1 h-4 w-4 rounded border-[#8B8477] text-[#1B4332] focus:ring-[#1B4332] cursor-pointer"
            />
            <label htmlFor="consent-checkbox" className="text-xs text-[#443E36] leading-relaxed cursor-pointer">
              <span className="font-semibold text-[#1B4332] flex items-center gap-1 mb-1">
                <ShieldCheck size={14} className="text-[#1B4332]" />
                Cultural Custodian Consent & Open Preservation Agreement
              </span>
              I affirm that I have the cultural consent or personal right to share this tradition. I
              agree that it will be preserved in the public Virasat cultural repository under open
              access fair use. I acknowledge that AI annotations and translations are interpretive and
              do not constitute formal historical certification.
            </label>
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#E5DDD0]">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-xs font-semibold text-[#6B655B] hover:text-[#22201D] rounded-md transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting || !consentGiven}
            className="px-6 py-2.5 text-xs font-semibold text-white bg-[#1B4332] hover:bg-[#2D6A4F] disabled:opacity-50 rounded-md transition-colors cursor-pointer shadow-xs"
          >
            {isSubmitting ? "Preserving Tradition..." : "Deposit in Virasat Archive"}
          </button>
        </div>
      </form>
    </div>
  );
};
