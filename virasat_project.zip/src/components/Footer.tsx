import React from "react";

interface FooterProps {
  onOpenAbout: () => void;
  onOpenExportGuide: () => void;
  onTabChange: (tab: "archive" | "preserve" | "ask") => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenAbout,
  onOpenExportGuide,
  onTabChange,
}) => {
  return (
    <footer className="border-t border-[#E5DDD0] bg-[#FAF7F2] py-12 text-[#6B655B] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-[#E5DDD0]">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-serif font-bold text-[#1B4332]">Virasat</span>
              <span className="text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
                વિरासत · विरासत
              </span>
            </div>
            <p className="mt-1 text-xs text-[#554F45]">
              “Every tradition deserves a tomorrow.” An open, AI-assisted cultural heritage repository.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-[#554F45]">
            <button
              onClick={() => onTabChange("archive")}
              className="hover:text-[#1B4332] transition-colors cursor-pointer"
            >
              Archive Catalog
            </button>
            <button
              onClick={() => onTabChange("preserve")}
              className="hover:text-[#1B4332] transition-colors cursor-pointer"
            >
              Contribute Tradition
            </button>
            <button
              onClick={() => onTabChange("ask")}
              className="hover:text-[#1B4332] transition-colors cursor-pointer"
            >
              Ask Curator
            </button>
            <button
              onClick={onOpenAbout}
              className="hover:text-[#1B4332] transition-colors cursor-pointer"
            >
              About Virasat
            </button>
            <button
              onClick={onOpenExportGuide}
              className="hover:text-[#1B4332] transition-colors cursor-pointer"
            >
              Export & Share
            </button>
          </div>
        </div>

        <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-[#8B8477] text-[11px] leading-relaxed">
          <p>
            Virasat preserves community oral histories and indigenous practices. Community submissions
            are unverified folk records. AI translations and summaries are generated for educational
            discovery.
          </p>
          <p className="shrink-0">
            Open Cultural Preservation Protocol · MIT License
          </p>
        </div>
      </div>
    </footer>
  );
};
