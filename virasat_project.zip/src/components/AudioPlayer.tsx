import React from "react";
import { Volume2, ExternalLink, Music, Radio, Disc } from "lucide-react";
import { AudioSource } from "../types";

interface AudioPlayerProps {
  audioSource?: AudioSource;
  compact?: boolean;
}

export function parseAudioSourceType(url: string): { type: AudioSource["type"]; embedUrl: string } {
  const cleanUrl = url.trim();

  // YouTube match
  const ytMatch = cleanUrl.match(
    /(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/
  );
  if (ytMatch) {
    return {
      type: "youtube",
      embedUrl: `https://www.youtube.com/embed/${ytMatch[1]}?rel=0`,
    };
  }

  // Spotify match
  const spotifyMatch = cleanUrl.match(/open\.spotify\.com\/(track|episode|album)\/([a-zA-Z0-9]+)/);
  if (spotifyMatch) {
    return {
      type: "spotify",
      embedUrl: `https://open.spotify.com/embed/${spotifyMatch[1]}/${spotifyMatch[2]}?utm_source=generator&theme=0`,
    };
  }

  // Internet Archive match
  if (cleanUrl.includes("archive.org")) {
    return {
      type: "internet_archive",
      embedUrl: cleanUrl,
    };
  }

  // Direct Audio file URL
  return {
    type: "audio_url",
    embedUrl: cleanUrl,
  };
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ audioSource, compact = false }) => {
  if (!audioSource || !audioSource.url) {
    return (
      <div className="p-3 bg-[#FAF7F2] border border-dashed border-[#D5C9B7] rounded-md text-xs text-[#8B8477] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Volume2 size={15} className="text-[#8B8477]" />
          <span>No audio recording attached to this tradition yet.</span>
        </div>
      </div>
    );
  }

  const { type, embedUrl } = parseAudioSourceType(audioSource.url);

  // Compact card preview
  if (compact) {
    return (
      <div className="flex items-center justify-between gap-2 text-xs py-1.5 px-2.5 bg-[#FAF7F2] border border-[#E5DDD0] rounded-md hover:border-[#1B4332] transition-colors">
        <a
          href={audioSource.url}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="flex items-center gap-2 truncate group/link hover:text-[#A64B2A] transition-colors"
          title={`Open original recording on ${type === "youtube" ? "YouTube" : type === "spotify" ? "Spotify" : "source"}`}
        >
          {type === "youtube" && <Disc size={13} className="text-red-700 shrink-0" />}
          {type === "spotify" && <Radio size={13} className="text-emerald-700 shrink-0" />}
          {(type === "audio_url" || type === "internet_archive") && (
            <Music size={13} className="text-[#1B4332] shrink-0" />
          )}
          <span className="truncate font-medium text-[#22201D] group-hover/link:text-[#A64B2A]">
            {audioSource.title || "Original Field Recording"}
          </span>
          <ExternalLink size={10} className="text-[#8B8477] opacity-60 group-hover/link:opacity-100 shrink-0" />
        </a>
        <span className="text-[10px] text-[#A64B2A] font-semibold shrink-0 uppercase tracking-wider">
          {type === "youtube" ? "YouTube" : type === "spotify" ? "Spotify" : "Audio"}
        </span>
      </div>
    );
  }

  // Full Player in Modal / Detail view
  return (
    <div className="p-4 bg-white border border-[#E5DDD0] rounded-lg space-y-3">
      {/* Header bar */}
      <div className="flex items-center justify-between border-b border-[#F0EAE1] pb-2">
        <div className="flex items-center gap-2">
          {type === "youtube" && <Disc size={15} className="text-red-700" />}
          {type === "spotify" && <Radio size={15} className="text-emerald-700" />}
          {(type === "audio_url" || type === "internet_archive") && (
            <Music size={15} className="text-[#1B4332]" />
          )}
          <div className="text-xs font-semibold text-[#1B4332]">
            <span>Authentic Recording</span>
            {audioSource.title && (
              <span className="text-[#6B655B] font-normal"> · {audioSource.title}</span>
            )}
          </div>
        </div>

        <a
          href={audioSource.url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs text-[#A64B2A] bg-[#FAF7F2] border border-[#D5C9B7] rounded hover:bg-[#EFE9DF] font-medium transition-colors"
        >
          <span>Open on {type === "youtube" ? "YouTube" : type === "spotify" ? "Spotify" : "Source"}</span>
          <ExternalLink size={12} />
        </a>
      </div>

      {/* Embedded Player per legal platform */}
      {type === "youtube" && (
        <div className="aspect-video w-full rounded-md overflow-hidden bg-black/5 shadow-2xs">
          <iframe
            src={embedUrl}
            title={audioSource.title || "YouTube Cultural Recording"}
            className="w-full h-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerPolicy="strict-origin-when-cross-origin"
            allowFullScreen
          />
        </div>
      )}

      {type === "spotify" && (
        <div className="w-full h-38 rounded-md overflow-hidden shadow-2xs">
          <iframe
            src={embedUrl}
            title={audioSource.title || "Spotify Cultural Track"}
            className="w-full h-full border-0"
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
            loading="lazy"
          />
        </div>
      )}

      {(type === "audio_url" || type === "internet_archive") && (
        <div className="pt-1">
          <audio controls className="w-full h-10 accent-[#1B4332] rounded">
            <source src={embedUrl} />
            Your browser does not support the audio element.
          </audio>
        </div>
      )}

      {/* Attribution notice */}
      {audioSource.attribution && (
        <div className="text-[11px] text-[#8B8477] italic pt-1">
          Recording credit: {audioSource.attribution}
        </div>
      )}
    </div>
  );
};
