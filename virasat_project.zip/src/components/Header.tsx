import React, { useState } from "react";
import { Menu, X, Feather } from "lucide-react";

interface HeaderProps {
  activeTab: "archive" | "preserve" | "ask";
  onTabChange: (tab: "archive" | "preserve" | "ask") => void;
  onOpenAbout: () => void;
  onOpenExportGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  onOpenAbout,
  onOpenExportGuide,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-sm border-b border-[#E5DDD0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              onTabChange("archive");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            className="text-left focus:outline-none group flex items-baseline gap-2.5 cursor-pointer"
          >
            <span className="text-3xl font-serif font-bold tracking-tight text-[#1B4332] group-hover:text-[#2D6A4F] transition-colors">
              Virasat
            </span>
            <span className="hidden sm:inline-block text-xs uppercase tracking-widest text-[#A64B2A] font-medium font-sans">
              વિरासत
            </span>
          </button>
        </div>

        {/* Zone 2: Navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#6B655B]">
          <button
            onClick={() => onTabChange("archive")}
            className={`whitespace-nowrap transition-colors hover:text-[#1B4332] cursor-pointer py-1 ${
              activeTab === "archive"
                ? "text-[#1B4332] font-semibold border-b-2 border-[#1B4332]"
                : ""
            }`}
          >
            Cultural Archive
          </button>
          <button
            onClick={() => onTabChange("preserve")}
            className={`whitespace-nowrap transition-colors hover:text-[#1B4332] cursor-pointer py-1 ${
              activeTab === "preserve"
                ? "text-[#1B4332] font-semibold border-b-2 border-[#1B4332]"
                : ""
            }`}
          >
            Preserve Tradition
          </button>
          <button
            onClick={() => onTabChange("ask")}
            className={`whitespace-nowrap transition-colors hover:text-[#1B4332] cursor-pointer py-1 ${
              activeTab === "ask"
                ? "text-[#1B4332] font-semibold border-b-2 border-[#1B4332]"
                : ""
            }`}
          >
            Ask Archive
          </button>
          <button
            onClick={onOpenAbout}
            className="whitespace-nowrap transition-colors hover:text-[#1B4332] cursor-pointer py-1"
          >
            About Virasat
          </button>
          <button
            onClick={onOpenExportGuide}
            className="whitespace-nowrap transition-colors hover:text-[#1B4332] cursor-pointer py-1"
          >
            Export & Share
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onTabChange("preserve")}
            className="hidden sm:inline-flex items-center gap-1.5 justify-center px-4 py-2 text-xs font-semibold text-white bg-[#1B4332] hover:bg-[#2D6A4F] active:bg-[#143225] rounded-md transition-colors tracking-wide cursor-pointer shadow-xs"
          >
            <Feather size={13} />
            <span>Preserve a Tradition</span>
          </button>

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#22201D] hover:text-[#1B4332] rounded-md border border-[#E5DDD0] cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E5DDD0] bg-[#FAF7F2] px-4 pt-3 pb-5 space-y-2">
          <button
            onClick={() => {
              onTabChange("archive");
              setMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3 py-2 text-sm rounded-md ${
              activeTab === "archive" ? "bg-[#EFE9DF] text-[#1B4332] font-semibold" : "text-[#6B655B]"
            }`}
          >
            Cultural Archive
          </button>
          <button
            onClick={() => {
              onTabChange("preserve");
              setMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3 py-2 text-sm rounded-md ${
              activeTab === "preserve" ? "bg-[#EFE9DF] text-[#1B4332] font-semibold" : "text-[#6B655B]"
            }`}
          >
            Preserve a Tradition
          </button>
          <button
            onClick={() => {
              onTabChange("ask");
              setMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3 py-2 text-sm rounded-md ${
              activeTab === "ask" ? "bg-[#EFE9DF] text-[#1B4332] font-semibold" : "text-[#6B655B]"
            }`}
          >
            Ask Archive (Curator Q&A)
          </button>
          <button
            onClick={() => {
              onOpenAbout();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm text-[#6B655B] hover:text-[#1B4332]"
          >
            About Virasat
          </button>
          <button
            onClick={() => {
              onOpenExportGuide();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 text-sm text-[#6B655B] hover:text-[#1B4332]"
          >
            Export & Share
          </button>
        </div>
      )}
    </header>
  );
};
