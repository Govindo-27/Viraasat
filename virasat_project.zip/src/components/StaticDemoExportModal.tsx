import React, { useState } from "react";
import { X, Download, Copy, Check, Share2, BookOpen, Link, Quote } from "lucide-react";
import { Tradition } from "../types";

interface StaticDemoExportModalProps {
  traditions: Tradition[];
  onClose: () => void;
}

export const StaticDemoExportModal: React.FC<StaticDemoExportModalProps> = ({
  traditions,
  onClose,
}) => {
  const [copiedJson, setCopiedJson] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCitation, setCopiedCitation] = useState(false);

  const handleDownloadJson = () => {
    const dataStr = JSON.stringify(traditions, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "virasat-archive-export.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(traditions, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyCitation = () => {
    const citation = `Virasat Cultural Heritage Archive. "Virasat: Open Community Repository of Living Traditions." Accessed ${new Date().toLocaleDateString(
      "en-US",
      { year: "numeric", month: "long", day: "numeric" }
    )}. ${window.location.href}`;
    navigator.clipboard.writeText(citation);
    setCopiedCitation(true);
    setTimeout(() => setCopiedCitation(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="animate-modal-in relative bg-[#FAF7F2] border border-[#E5DDD0] w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl p-6 sm:p-8 text-left my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#E5DDD0]">
          <div className="flex items-center gap-2.5">
            <Share2 className="text-[#1B4332]" size={22} />
            <div>
              <h3 className="text-xl font-serif font-bold text-[#1B4332]">
                Export & Share Archive
              </h3>
              <p className="text-xs text-[#6B655B]">
                Open cultural heritage dataset & preservation formats
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6B655B] hover:text-[#1B4332] rounded-md hover:bg-[#EFE9DF] transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </div>

        {/* Dataset Summary & Download */}
        <div className="mt-5 p-4 rounded-lg bg-white border border-[#E5DDD0] text-xs text-[#443E36] space-y-2.5">
          <div className="flex items-center gap-1.5 font-bold text-[#1B4332] text-sm">
            <BookOpen size={16} className="text-[#A64B2A]" />
            <span>Open Access Cultural Repository</span>
          </div>
          <p className="leading-relaxed text-[#6B655B]">
            All community contributions in Virasat are archived in standardized UTF-8 JSON format with
            their original scripts, translations, and curatorial metadata. You can export the dataset for
            offline preservation, research, and non-commercial community archiving.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={handleDownloadJson}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-[#1B4332] text-white rounded-md hover:bg-[#2D6A4F] transition-colors cursor-pointer shadow-xs"
            >
              <Download size={13} />
              <span>Download Dataset ({traditions.length} records)</span>
            </button>
            <button
              onClick={handleCopyJson}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-white border border-[#D5C9B7] text-[#1B4332] rounded-md hover:bg-[#FAF7F2] transition-colors cursor-pointer"
            >
              {copiedJson ? <Check size={13} className="text-emerald-700" /> : <Copy size={13} />}
              <span>{copiedJson ? "Copied JSON!" : "Copy Raw JSON"}</span>
            </button>
          </div>
        </div>

        {/* Share & Citation Tools */}
        <div className="mt-6 space-y-3">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-[#1B4332]">
            Share & Archival Citation
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Copy Shareable Link */}
            <div className="p-3.5 bg-white border border-[#E5DDD0] rounded-lg flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 font-semibold text-[#1B4332] mb-1">
                  <Link size={14} className="text-[#A64B2A]" />
                  <span>Shareable Web Link</span>
                </div>
                <p className="text-[11px] text-[#6B655B] leading-relaxed">
                  Share direct access to the Virasat repository with fellow researchers and custodians.
                </p>
              </div>
              <button
                onClick={handleCopyLink}
                className="mt-3 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1B4332] bg-[#FAF7F2] hover:bg-[#EFE9DF] border border-[#D5C9B7] rounded-md transition-colors cursor-pointer"
              >
                {copiedLink ? <Check size={13} className="text-emerald-700" /> : <Copy size={13} />}
                <span>{copiedLink ? "Link Copied!" : "Copy Link"}</span>
              </button>
            </div>

            {/* Academic & Catalog Citation */}
            <div className="p-3.5 bg-white border border-[#E5DDD0] rounded-lg flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 font-semibold text-[#1B4332] mb-1">
                  <Quote size={14} className="text-[#A64B2A]" />
                  <span>Formal Citation</span>
                </div>
                <p className="text-[11px] text-[#6B655B] leading-relaxed">
                  Generate formatted attribution for bibliographies, papers, and exhibition catalogs.
                </p>
              </div>
              <button
                onClick={handleCopyCitation}
                className="mt-3 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1B4332] bg-[#FAF7F2] hover:bg-[#EFE9DF] border border-[#D5C9B7] rounded-md transition-colors cursor-pointer"
              >
                {copiedCitation ? <Check size={13} className="text-emerald-700" /> : <Copy size={13} />}
                <span>{copiedCitation ? "Citation Copied!" : "Copy Citation"}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dataset Specifications Strip */}
        <div className="mt-6 pt-4 border-t border-[#E5DDD0] flex flex-wrap items-center justify-between gap-3 text-xs text-[#8B8477]">
          <div>Format: UTF-8 JSON · Schema v1.0 · Open Fair Use</div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#EFE9DF] hover:bg-[#E5DDD0] text-[#1B4332] text-xs font-semibold rounded-md transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
