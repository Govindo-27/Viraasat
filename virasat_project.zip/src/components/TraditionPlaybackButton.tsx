import React, { useState, useEffect } from "react";
import { Play, Pause, Loader2, Volume2, Sparkles, Settings2, Check, Headphones } from "lucide-react";
import { Tradition } from "../types";
import { voiceService, VoicePlaybackState, VoiceOption } from "../services/voiceService";

interface TraditionPlaybackButtonProps {
  tradition: Tradition;
  size?: "sm" | "md";
  className?: string;
  showVoiceSelector?: boolean;
}

export const TraditionPlaybackButton: React.FC<TraditionPlaybackButtonProps> = ({
  tradition,
  size = "sm",
  className = "",
  showVoiceSelector = false,
}) => {
  const [playbackState, setPlaybackState] = useState<VoicePlaybackState>(voiceService.getState());
  const [showSettings, setShowSettings] = useState(false);
  const [customKeyInput, setCustomKeyInput] = useState(voiceService.getCustomApiKey());
  const [keySaved, setKeySaved] = useState(false);
  const [voices, setVoices] = useState<VoiceOption[]>(voiceService.getVoices());

  useEffect(() => {
    const unsubscribe = voiceService.subscribe((state) => {
      setPlaybackState(state);
    });
    setVoices(voiceService.getVoices());
    return () => {
      unsubscribe();
    };
  }, []);

  const isCurrentTradition = playbackState.traditionId === tradition.id;
  const isPlaying = isCurrentTradition && playbackState.isPlaying;
  const isLoading = isCurrentTradition && playbackState.isLoading;
  const hasError = isCurrentTradition && Boolean(playbackState.error);

  const handleTogglePlay = async (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent opening card modal
    if (isLoading) return;

    try {
      await voiceService.toggle(tradition);
    } catch (err) {
      console.error("Playback toggle error:", err);
    }
  };

  const handleOpenSettings = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowSettings(!showSettings);
  };

  const handleSaveKey = (e: React.MouseEvent) => {
    e.stopPropagation();
    voiceService.setCustomApiKey(customKeyInput);
    setKeySaved(true);
    setTimeout(() => setKeySaved(false), 2000);
  };

  const handleSelectVoice = (e: React.MouseEvent, voiceId: string) => {
    e.stopPropagation();
    voiceService.setSelectedVoice(voiceId);
  };

  // Format seconds as m:ss
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "0:00";
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  return (
    <div className={`relative inline-flex items-center gap-1.5 ${className}`}>
      {/* Primary Playback Pill / Button */}
      <button
        type="button"
        onClick={handleTogglePlay}
        disabled={isLoading}
        title={
          isPlaying
            ? "Pause AI Voice Narration"
            : hasError
            ? "Retry AI Voice Narration"
            : "Listen to AI Voice Narration (Human-like synthesis)"
        }
        aria-label={
          isPlaying
            ? `Pause narration for ${tradition.title}`
            : `Listen to narration for ${tradition.title}`
        }
        className={`group inline-flex items-center gap-1.5 font-medium rounded-full transition-all cursor-pointer select-none ${
          size === "sm" ? "px-2.5 py-1 text-xs" : "px-3.5 py-1.5 text-sm"
        } ${
          isPlaying
            ? "bg-[#1B4332] text-white shadow-sm ring-2 ring-[#1B4332]/20"
            : hasError
            ? "bg-rose-50 border border-rose-300 text-rose-800 hover:bg-rose-100"
            : "bg-[#FAF7F2] border border-[#D5C9B7] text-[#1B4332] hover:bg-[#EFE9DF] hover:border-[#1B4332]"
        }`}
      >
        {isLoading ? (
          <Loader2
            size={size === "sm" ? 12 : 14}
            className="animate-spin text-[#1B4332] shrink-0"
          />
        ) : isPlaying ? (
          <Pause size={size === "sm" ? 12 : 14} className="shrink-0 fill-current" />
        ) : (
          <Play
            size={size === "sm" ? 12 : 14}
            className="shrink-0 fill-[#A64B2A] text-[#A64B2A] group-hover:scale-110 transition-transform"
          />
        )}

        {/* Label & Soundwave */}
        <span className="font-serif tracking-wide">
          {isLoading
            ? "Synthesizing..."
            : isPlaying
            ? "Playing"
            : hasError
            ? "Retry Voice"
            : "Listen"}
        </span>

        {/* Live Soundwave Bars Animation when playing */}
        {isPlaying && (
          <div className="flex items-center gap-0.5 ml-0.5 h-3">
            <span className="w-0.5 h-2.5 bg-white/90 rounded-full animate-pulse" />
            <span
              className="w-0.5 h-3.5 bg-white rounded-full animate-pulse"
              style={{ animationDelay: "150ms" }}
            />
            <span
              className="w-0.5 h-2 bg-white/80 rounded-full animate-pulse"
              style={{ animationDelay: "300ms" }}
            />
          </div>
        )}

        {/* Duration / Progress when active */}
        {isPlaying && playbackState.duration > 0 && (
          <span className="text-[10px] tabular-nums font-mono opacity-90 pl-0.5">
            {formatTime(playbackState.currentTime)} / {formatTime(playbackState.duration)}
          </span>
        )}

        {/* Subtle AI Voice Indicator Pill */}
        {!isPlaying && !isLoading && !hasError && (
          <span className="inline-flex items-center gap-0.5 px-1 py-0.2 bg-[#EFE9DF] text-[#7C3A21] rounded text-[9px] font-sans font-semibold tracking-wider uppercase ml-0.5">
            <Sparkles size={8} />
            AI Voice
          </span>
        )}
      </button>

      {/* Voice Options / Key Config Trigger (Optional toggle) */}
      {showVoiceSelector && (
        <button
          type="button"
          onClick={handleOpenSettings}
          title="Narrator Voice Options & API Key"
          aria-label="Voice settings"
          className="p-1 text-[#8B8477] hover:text-[#1B4332] hover:bg-[#EFE9DF] rounded-md transition-colors cursor-pointer"
        >
          <Settings2 size={13} />
        </button>
      )}

      {/* Quick Settings Dropdown Popover */}
      {showSettings && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute left-0 top-full mt-2 z-50 w-72 bg-white border border-[#D5C9B7] rounded-lg shadow-xl p-3 text-left animate-fade-in"
        >
          <div className="flex items-center justify-between pb-2 border-b border-[#F0EAE1]">
            <span className="text-xs font-semibold text-[#1B4332] flex items-center gap-1.5">
              <Volume2 size={13} className="text-[#A64B2A]" />
              AI Voice Narrators
            </span>
            <span className="text-[10px] text-[#8B8477]">ElevenLabs / Neural</span>
          </div>

          {/* Voice Picker List */}
          <div className="mt-2 space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-[#8B8477] font-semibold">
              Select Narrator
            </div>
            {voices.map((v) => (
              <button
                key={v.id}
                type="button"
                onClick={(e) => handleSelectVoice(e, v.id)}
                className={`w-full text-left px-2 py-1.5 rounded text-xs flex items-center justify-between transition-colors cursor-pointer ${
                  playbackState.voiceId === v.id
                    ? "bg-[#1B4332] text-white font-medium"
                    : "hover:bg-[#FAF7F2] text-[#443E36]"
                }`}
              >
                <div>
                  <div className="font-serif">{v.name}</div>
                  <div
                    className={`text-[10px] ${
                      playbackState.voiceId === v.id ? "text-stone-300" : "text-[#8B8477]"
                    }`}
                  >
                    {v.description}
                  </div>
                </div>
                {playbackState.voiceId === v.id && <Check size={12} className="shrink-0 ml-1" />}
              </button>
            ))}
          </div>

          {/* Natural Playback Tempo Controller */}
          <div className="mt-2.5 pt-2 border-t border-[#F0EAE1]">
            <div className="text-[10px] uppercase tracking-wider text-[#8B8477] font-semibold mb-1 flex items-center justify-between">
              <span>Playback Tempo</span>
              <span className="font-mono text-[#1B4332] font-bold">
                {(playbackState.playbackRate || 1.0).toFixed(playbackState.playbackRate === 1 ? 1 : 2)}x Natural
              </span>
            </div>
            <div className="flex items-center gap-1">
              {[
                { speed: 0.9, label: "0.9x" },
                { speed: 1.0, label: "1.0x" },
                { speed: 1.15, label: "1.15x" },
                { speed: 1.25, label: "1.25x" },
                { speed: 1.5, label: "1.5x" },
              ].map((item) => (
                <button
                  key={item.speed}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    voiceService.setPlaybackRate(item.speed);
                  }}
                  className={`flex-1 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer text-center ${
                    (playbackState.playbackRate || 1.0) === item.speed
                      ? "bg-[#1B4332] text-white font-bold"
                      : "bg-[#FAF7F2] text-[#443E36] hover:bg-[#EFE9DF]"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* 3 Explicit Language Audio Choices: Hindi, Regional Dialects, English */}
          <div className="mt-3 pt-2.5 border-t border-[#F0EAE1]">
            <div className="text-[10px] uppercase tracking-wider text-[#A64B2A] font-semibold flex items-center justify-between mb-1.5">
              <span className="flex items-center gap-1">
                <Headphones size={11} />
                <span>Listen In (भाषा चुनें):</span>
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  voiceService.toggleTanpuraWarmth();
                }}
                className="text-[9px] text-[#8B4513] hover:underline cursor-pointer"
                title="Toggle gentle acoustic tanpura accompaniment"
              >
                {voiceService.isTanpuraActive() ? "🌾 तंबूरा: On" : "🌾 तंबूरा: Off"}
              </button>
            </div>

            {/* 3 Primary Columns/Pills */}
            <div className="space-y-1.5">
              {/* 1. Hindi */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  voiceService.playRegional(tradition, "hindi", "all");
                  setShowSettings(false);
                }}
                className="w-full px-2 py-1.5 bg-[#FAF7F2] hover:bg-[#EFE9DF] border border-[#D5C9B7] rounded text-left text-xs font-serif text-[#1B4332] flex items-center justify-between transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-1.5 text-xs">
                  <span>🇮🇳</span>
                  <span className="font-semibold">हिन्दी (Hindi)</span>
                  <span className="text-[10px] text-[#7C7467] font-sans">मानक वाचिक</span>
                </span>
                <Play size={9} className="fill-[#1B4332] text-[#1B4332]" />
              </button>

              {/* 2. English */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  voiceService.playRegional(tradition, "english", "all");
                  setShowSettings(false);
                }}
                className="w-full px-2 py-1.5 bg-[#FAF7F2] hover:bg-[#EFE9DF] border border-[#D5C9B7] rounded text-left text-xs font-serif text-[#1B4332] flex items-center justify-between transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-1.5 text-xs">
                  <span>🌐</span>
                  <span className="font-semibold">English</span>
                  <span className="text-[10px] text-[#7C7467] font-sans">Scholarly Oral</span>
                </span>
                <Play size={9} className="fill-[#1B4332] text-[#1B4332]" />
              </button>

              {/* 3. Regional Dialects Grid */}
              <div className="pt-1">
                <div className="text-[10px] font-semibold text-[#8B8477] uppercase tracking-wider mb-1">
                  🌾 Regional Dialects (क्षेत्रीय बोलियाँ):
                </div>
                <div className="grid grid-cols-2 gap-1">
                  {[
                    { id: "bhojpuri", label: "भोजपुरी", name: "Bhojpuri", flag: "🌾" },
                    { id: "kashmiri", label: "कॉशुर", name: "Kashmiri", flag: "🏔️" },
                    { id: "nagpuri", label: "नागपुरी", name: "Nagpuri", flag: "🌿" },
                    { id: "maithili", label: "मैथिली", name: "Maithili", flag: "📜" },
                    { id: "awadhi", label: "अवधी", name: "Awadhi", flag: "🪔" },
                    { id: "bengali", label: "বাংলা", name: "Bengali", flag: "🌊" },
                  ].map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        voiceService.playRegional(tradition, item.id, "all");
                        setShowSettings(false);
                      }}
                      className="px-2 py-1 bg-white hover:bg-[#FAF7F2] border border-[#D5C9B7] rounded text-left text-xs font-serif text-[#1B4332] flex items-center justify-between transition-colors cursor-pointer"
                      title={`Listen to ${tradition.title} in ${item.name}`}
                    >
                      <span className="flex items-center gap-1 text-[11px]">
                        <span>{item.flag}</span>
                        <span className="font-medium">{item.label}</span>
                      </span>
                      <Play size={8} className="fill-[#A64B2A] text-[#A64B2A]" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Optional ElevenLabs API Key Input */}
          <div className="mt-3 pt-2.5 border-t border-[#F0EAE1]">
            <label
              htmlFor={`eleven-key-${tradition.id}`}
              className="block text-[10px] uppercase tracking-wider text-[#8B8477] font-semibold mb-1"
            >
              Custom ElevenLabs API Key (Optional)
            </label>
            <div className="flex items-center gap-1.5">
              <input
                id={`eleven-key-${tradition.id}`}
                type="password"
                placeholder="sk_..."
                value={customKeyInput}
                onChange={(e) => setCustomKeyInput(e.target.value)}
                className="w-full px-2 py-1 text-xs border border-[#D5C9B7] rounded focus:outline-none focus:ring-1 focus:ring-[#1B4332] font-mono"
              />
              <button
                type="button"
                onClick={handleSaveKey}
                className="px-2 py-1 text-xs bg-[#1B4332] text-white rounded hover:bg-[#2D6A4F] font-medium shrink-0 cursor-pointer"
              >
                {keySaved ? "Saved" : "Save"}
              </button>
            </div>
            <p className="text-[10px] text-[#8B8477] mt-1 leading-normal">
              Stored locally. Falls back to Gemini neural voice if empty.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
