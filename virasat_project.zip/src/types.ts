export interface CuratorNotes {
  summary: string;
  tags: string[];
  englishTranslation?: string | null;
  generatedAt?: string;
  model?: string;
  isAiCurated: boolean;
}

export interface AudioSource {
  type: "youtube" | "spotify" | "audio_url" | "internet_archive";
  url: string;
  title?: string;
  attribution?: string;
  duration?: string;
}

export interface MediaTutorial {
  youtube?: {
    videoId: string;
    url: string;
    embedUrl: string;
    title: string;
    tutorialType: string;
  };
  spotify?: {
    trackId: string;
    url: string;
    embedUrl: string;
    title: string;
    artist?: string;
  };
  vocalGuide?: {
    heading: string;
    ragaTaal: string;
    techniqueTips: string[];
  };
  equipmentCraftGuide?: {
    heading: string;
    materials: string[];
    steps: string[];
  };
  recipeGuide?: {
    heading: string;
    ingredients: string[];
    steps: string[];
  };
}

export interface Tradition {
  id: string;
  title: string;
  category: string;
  language: string;
  region: string;
  contributorName: string;
  datePreserved: string;
  originalText: string;
  consentGiven: boolean;
  verifiedStatus: string;
  curatorNotes?: CuratorNotes;
  audioSource?: AudioSource;
  mediaTutorial?: MediaTutorial;
}

export interface SystemStatus {
  status: string;
  archiveEntries: number;
  storage: string;
  aiCurator: string;
}

export type HeritageCategory =
  | "All"
  | "Stories"
  | "Recipes"
  | "Folk Practices"
  | "Festivals"
  | "Traditional Crafts"
  | "Oral Histories"
  | "Music & Performing Arts";

export interface RegionalLanguageOption {
  id: string;
  name: string;
  nativeName: string;
  flag: string;
  description: string;
}

export interface RegionalNarrationData {
  traditionId: string;
  langId: string;
  language: string;
  nativeName: string;
  flag: string;
  caption: string;
  description: string;
  fullText: string;
  audioUrls: {
    all: string;
    caption: string;
    description: string;
  };
}

