import { Tradition } from "../types";

export interface VoiceOption {
  id: string;
  name: string;
  gender: string;
  description: string;
}

export interface VoicePlaybackState {
  isPlaying: boolean;
  isLoading: boolean;
  traditionId: string | null;
  traditionTitle: string | null;
  currentTime: number;
  duration: number;
  voiceId: string;
  voiceName: string;
  engine: "gemini" | "speechSynthesis" | "elevenlabs" | "ambient";
  language: string;
  activePart: "all" | "caption" | "description";
  error: string | null;
  tanpuraActive: boolean;
  currentSpokenSentence: string | null;
  playbackRate: number;
}

const DEFAULT_VOICES: VoiceOption[] = [
  {
    id: "21m00Tcm4TlvDq8ikWAM",
    name: "Rachel (Oral Storyteller)",
    gender: "Female",
    description: "Warm, natural cadence, ideal for living traditions & oral history",
  },
  {
    id: "ErXwobaYiN019PkySvjV",
    name: "Antoni (Chronicler)",
    gender: "Male",
    description: "Resonant, scholarly, and clear for archival recitations",
  },
  {
    id: "EXAVITQu4vr4xnSDxMaL",
    name: "Bella (Folk Voice)",
    gender: "Female",
    description: "Expressive and evocative for rituals, chants, and songs",
  },
  {
    id: "onwK4e9ZLuTAKqWW03F9",
    name: "Daniel (Archivist)",
    gender: "Male",
    description: "Authoritative documentary voice for historical preservation",
  },
];

type StateListener = (state: VoicePlaybackState) => void;

class VoiceService {
  private audio: HTMLAudioElement | null = null;
  private synthUtterance: SpeechSynthesisUtterance | null = null;
  private audioContext: AudioContext | null = null;
  private tanpuraOscillators: OscillatorNode[] = [];
  private tanpuraGain: GainNode | null = null;
  private tanpuraActive = false;
  private isSpeakingHuman = false;
  private sentencePauseTimer: any = null;
  private playbackRate = 1.0;
  private browserVoices: SpeechSynthesisVoice[] = [];

  private state: VoicePlaybackState = {
    isPlaying: false,
    isLoading: false,
    traditionId: null,
    traditionTitle: null,
    currentTime: 0,
    duration: 0,
    voiceId: "21m00Tcm4TlvDq8ikWAM",
    voiceName: "Rachel (Oral Storyteller)",
    engine: "gemini",
    language: "hindi",
    activePart: "all",
    error: null,
    tanpuraActive: false,
    currentSpokenSentence: null,
    playbackRate: 1.0,
  };

  private listeners: Set<StateListener> = new Set();
  private availableVoices: VoiceOption[] = DEFAULT_VOICES;

  constructor() {
    if (typeof window !== "undefined") {
      const savedKey = localStorage.getItem("virasat_elevenlabs_key");
      const savedVoice = localStorage.getItem("virasat_selected_voice");
      const savedTanpura = localStorage.getItem("virasat_tanpura_active");
      const savedRate = localStorage.getItem("virasat_playback_rate");
      if (savedRate) {
        const parsed = parseFloat(savedRate);
        if (!isNaN(parsed) && parsed >= 0.5 && parsed <= 2.5) {
          this.playbackRate = parsed;
          this.state.playbackRate = parsed;
        }
      }
      if (savedTanpura === "true") {
        this.tanpuraActive = true;
        this.state.tanpuraActive = true;
      }
      if (savedVoice) {
        const found = DEFAULT_VOICES.find((v) => v.id === savedVoice);
        if (found) {
          this.state.voiceId = found.id;
          this.state.voiceName = found.name;
        }
      }
      if (window.speechSynthesis) {
        const cacheVoices = () => {
          const v = window.speechSynthesis.getVoices();
          if (v && v.length > 0) {
            this.browserVoices = v;
          }
        };
        cacheVoices();
        window.speechSynthesis.onvoiceschanged = cacheVoices;
      }
      this.initAudioElement();
      this.fetchVoiceInfo();
    }
  }

  private initAudioElement() {
    if (typeof window === "undefined") return;
    this.audio = new Audio();
    this.audio.preload = "auto";
    this.audio.playbackRate = this.playbackRate;

    this.audio.addEventListener("playing", () => {
      if (this.audio) this.audio.playbackRate = this.playbackRate;
      this.updateState({ isPlaying: true, isLoading: false, error: null });
    });

    this.audio.addEventListener("pause", () => {
      this.updateState({ isPlaying: false });
    });

    this.audio.addEventListener("timeupdate", () => {
      if (!this.audio) return;
      this.updateState({
        currentTime: this.audio.currentTime,
        duration: this.audio.duration || this.state.duration,
      });
    });

    this.audio.addEventListener("loadedmetadata", () => {
      if (!this.audio) return;
      this.audio.playbackRate = this.playbackRate;
      this.updateState({
        duration: this.audio.duration || 0,
        isLoading: false,
      });
    });

    this.audio.addEventListener("ended", () => {
      this.stop();
    });

    this.audio.addEventListener("error", (e) => {
      console.warn("Audio element error, will use speech synthesis fallback:", e);
      this.updateState({
        isPlaying: false,
        isLoading: false,
        error: null,
      });
    });
  }

  private async fetchVoiceInfo() {
    try {
      const res = await fetch("/api/voice/info");
      if (res.ok) {
        const data = await res.json();
        if (data.voices && Array.isArray(data.voices) && data.voices.length > 0) {
          this.availableVoices = data.voices;
        }
      }
    } catch {
      // Keep defaults
    }
  }

  // Tanpura / Living Hearth Acoustic Bed Engine (Procedural Indian drone)
  public startTanpuraWarmth() {
    if (typeof window === "undefined") return;
    try {
      if (!this.audioContext) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        this.audioContext = new AudioCtx();
      }
      if (this.audioContext.state === "suspended") {
        this.audioContext.resume();
      }

      this.stopTanpuraWarmth();

      // Tanpura Kharaj & Pancham tuning (D note: 146.83 Hz, A note: 220 Hz, D octave: 293.66 Hz)
      const freqs = [146.83, 220.0, 293.66, 146.83 * 0.5];
      const masterGain = this.audioContext.createGain();
      masterGain.gain.setValueAtTime(0.001, this.audioContext.currentTime);
      // Gentle, subtle warmth (0.015) so it doesn't mask vocal clarity
      masterGain.gain.exponentialRampToValueAtTime(0.015, this.audioContext.currentTime + 1.2);
      masterGain.connect(this.audioContext.destination);
      this.tanpuraGain = masterGain;

      this.tanpuraOscillators = freqs.map((freq, i) => {
        const osc = this.audioContext!.createOscillator();
        const oscGain = this.audioContext!.createGain();
        osc.type = i === 1 ? "triangle" : "sine";
        // Subtle detune for natural acoustic beating
        osc.frequency.setValueAtTime(freq, this.audioContext!.currentTime);
        osc.detune.setValueAtTime((i - 1.5) * 2.5, this.audioContext!.currentTime);

        oscGain.gain.value = 0.25 / (i + 1);
        osc.connect(oscGain);
        oscGain.connect(masterGain);
        osc.start();
        return osc;
      });

      this.tanpuraActive = true;
      localStorage.setItem("virasat_tanpura_active", "true");
      this.updateState({ tanpuraActive: true });
    } catch (e) {
      console.warn("Could not start tanpura warmth bed:", e);
    }
  }

  public stopTanpuraWarmth() {
    if (this.tanpuraGain && this.audioContext) {
      try {
        this.tanpuraGain.gain.setValueAtTime(this.tanpuraGain.gain.value, this.audioContext.currentTime);
        this.tanpuraGain.gain.exponentialRampToValueAtTime(0.0001, this.audioContext.currentTime + 0.4);
      } catch {}
    }
    setTimeout(() => {
      this.tanpuraOscillators.forEach((osc) => {
        try {
          osc.stop();
          osc.disconnect();
        } catch {}
      });
      this.tanpuraOscillators = [];
    }, 450);

    this.tanpuraActive = false;
    if (typeof window !== "undefined") {
      localStorage.setItem("virasat_tanpura_active", "false");
    }
    this.updateState({ tanpuraActive: false });
  }

  public toggleTanpuraWarmth() {
    if (this.tanpuraActive) {
      this.stopTanpuraWarmth();
    } else {
      this.startTanpuraWarmth();
    }
  }

  public isTanpuraActive(): boolean {
    return this.tanpuraActive;
  }

  public setPlaybackRate(rate: number) {
    const clamped = Math.max(0.5, Math.min(2.5, rate));
    this.playbackRate = clamped;
    if (this.audio) {
      this.audio.playbackRate = clamped;
    }
    this.updateState({ playbackRate: clamped });
    if (typeof window !== "undefined") {
      localStorage.setItem("virasat_playback_rate", clamped.toString());
    }
  }

  public getPlaybackRate(): number {
    return this.playbackRate;
  }

  // Find best natural human browser speech synthesis voice
  private getBestVoiceForLanguage(lang: string): SpeechSynthesisVoice | null {
    if (typeof window === "undefined" || !window.speechSynthesis) return null;
    const voices = this.browserVoices.length > 0 ? this.browserVoices : window.speechSynthesis.getVoices();
    if (!voices || voices.length === 0) return null;

    const lowerLang = (lang || "en").toLowerCase();

    const isNatural = (v: SpeechSynthesisVoice) =>
      v.name.includes("Natural") ||
      v.name.includes("Google") ||
      v.name.includes("Online") ||
      v.name.includes("Neural") ||
      v.name.includes("Premium");

    if (
      lowerLang.includes("hindi") ||
      lowerLang.includes("hi") ||
      lowerLang.includes("bhojpuri") ||
      lowerLang.includes("nagpuri") ||
      lowerLang.includes("maithili") ||
      lowerLang.includes("awadhi")
    ) {
      // 1. High-quality natural Hindi voice (Google हिन्दी, Microsoft Swara Natural, Madhur, Lekha)
      const naturalHi = voices.find(
        (v) =>
          v.lang.startsWith("hi") &&
          (isNatural(v) || v.name.includes("Swara") || v.name.includes("Madhur") || v.name.includes("Lekha"))
      );
      if (naturalHi) return naturalHi;

      const anyHi = voices.find((v) => v.lang.startsWith("hi") || v.lang.toLowerCase().includes("hi-in"));
      if (anyHi) return anyHi;
    } else if (lowerLang.includes("kashmiri") || lowerLang.includes("ur")) {
      const naturalUr = voices.find((v) => (v.lang.startsWith("ur") || v.lang.startsWith("hi")) && isNatural(v));
      if (naturalUr) return naturalUr;
      const anyUrdu = voices.find((v) => v.lang.startsWith("ur") || v.lang.startsWith("hi"));
      if (anyUrdu) return anyUrdu;
    } else if (lowerLang.includes("bengali") || lowerLang.includes("bn")) {
      const naturalBn = voices.find((v) => v.lang.startsWith("bn") && isNatural(v));
      if (naturalBn) return naturalBn;
      const anyBn = voices.find((v) => v.lang.startsWith("bn"));
      if (anyBn) return anyBn;
    }

    // English: Prefer natural Indian English or British/American natural
    const indianEnNatural = voices.find(
      (v) =>
        (v.lang === "en-IN" || v.lang.startsWith("en_IN")) &&
        (isNatural(v) || v.name.includes("Neerja") || v.name.includes("Prabhat"))
    );
    if (indianEnNatural) return indianEnNatural;

    const anyEnIn = voices.find((v) => v.lang === "en-IN" || v.lang.startsWith("en_IN"));
    if (anyEnIn) return anyEnIn;

    const naturalEn = voices.find(
      (v) => v.lang.startsWith("en") && (isNatural(v) || v.name.includes("Jenny") || v.name.includes("Guy") || v.name.includes("Samantha"))
    );
    if (naturalEn) return naturalEn;

    return voices.find((v) => v.lang.startsWith("en")) || voices[0] || null;
  }

  /**
   * Speak narrative text using human-cadence Web Speech API with natural sentence pacing
   */
  public playHumanNarration(
    text: string,
    lang = "hindi",
    traditionId = "",
    traditionTitle = "",
    part: "all" | "caption" | "description" = "all",
    rate?: number
  ): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === "undefined" || !window.speechSynthesis) {
        resolve();
        return;
      }

      this.stop();
      this.isSpeakingHuman = true;

      const activeRate = typeof rate === "number" && rate > 0 ? rate : this.playbackRate || 1.0;
      this.playbackRate = activeRate;

      // Clean text: strip markdown symbols and normalize spacing
      const cleanText = text
        .replace(/\*\*|\*|##|__|```/g, "")
        .replace(/[\r\n]+/g, " ")
        .trim();

      // Split into natural conversational sentences (handles Devanagari danda ।, periods, exclamation, questions)
      const rawSentences = cleanText.split(/(?<=[.!?।])\s+/);
      const sentences = rawSentences.map((s) => s.trim()).filter((s) => s.length > 0);
      if (sentences.length === 0) {
        sentences.push(cleanText);
      }

      const voice = this.getBestVoiceForLanguage(lang);

      this.updateState({
        isPlaying: true,
        isLoading: false,
        traditionId,
        traditionTitle: `${traditionTitle} (${lang})`,
        engine: "speechSynthesis",
        language: lang,
        activePart: part,
        error: null,
        playbackRate: activeRate,
        currentSpokenSentence: sentences[0],
      });

      const speakSentenceAt = (index: number) => {
        if (!this.isSpeakingHuman || index >= sentences.length) {
          this.stop();
          resolve();
          return;
        }

        const currentSentence = sentences[index];
        this.updateState({
          currentSpokenSentence: currentSentence,
          isPlaying: true,
        });

        const utterance = new SpeechSynthesisUtterance(currentSentence);
        if (voice) {
          utterance.voice = voice;
          utterance.lang = voice.lang;
        } else {
          const lower = lang.toLowerCase();
          if (
            lower.includes("hindi") ||
            lower.includes("bhojpuri") ||
            lower.includes("nagpuri") ||
            lower.includes("maithili") ||
            lower.includes("awadhi")
          ) {
            utterance.lang = "hi-IN";
          } else if (lower.includes("bengali")) {
            utterance.lang = "bn-IN";
          } else {
            utterance.lang = "en-IN";
          }
        }

        // Standard natural conversational pacing (1.0x default, clean resonance)
        utterance.rate = this.playbackRate;
        utterance.pitch = 1.0;

        this.synthUtterance = utterance;

        utterance.onend = () => {
          if (!this.isSpeakingHuman) return;
          // Natural conversational breath pause (120ms) between sentences
          this.sentencePauseTimer = setTimeout(() => {
            speakSentenceAt(index + 1);
          }, 120);
        };

        utterance.onerror = (e) => {
          if (e.error !== "canceled" && e.error !== "interrupted") {
            console.warn("Speech synthesis notice:", e);
          }
          if (this.isSpeakingHuman && index + 1 < sentences.length) {
            this.sentencePauseTimer = setTimeout(() => {
              speakSentenceAt(index + 1);
            }, 80);
          } else {
            this.stop();
            resolve();
          }
        };

        window.speechSynthesis.speak(utterance);
      };

      speakSentenceAt(0);
    });
  }

  public getVoices(): VoiceOption[] {
    return this.availableVoices;
  }

  public setCustomApiKey(key: string) {
    if (typeof window === "undefined") return;
    if (key && key.trim()) {
      localStorage.setItem("virasat_elevenlabs_key", key.trim());
    } else {
      localStorage.removeItem("virasat_elevenlabs_key");
    }
  }

  public getCustomApiKey(): string {
    if (typeof window === "undefined") return "";
    return localStorage.getItem("virasat_elevenlabs_key") || "";
  }

  public setSelectedVoice(voiceId: string) {
    const found = this.availableVoices.find((v) => v.id === voiceId);
    if (found) {
      this.state.voiceId = found.id;
      this.state.voiceName = found.name;
      if (typeof window !== "undefined") {
        localStorage.setItem("virasat_selected_voice", found.id);
      }
      this.notify();
    }
  }

  public getSelectedVoice(): string {
    return this.state.voiceId;
  }

  public getState(): VoicePlaybackState {
    return { ...this.state };
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const currentState = this.getState();
    this.listeners.forEach((listener) => {
      try {
        listener(currentState);
      } catch (err) {
        console.error("Listener error:", err);
      }
    });
  }

  private updateState(partial: Partial<VoicePlaybackState>) {
    this.state = { ...this.state, ...partial };
    this.notify();
  }

  public getNarrationText(
    tradition: Tradition,
    textType?: "summary" | "translation" | "original"
  ): string {
    if (textType === "original" && tradition.originalText) {
      return tradition.originalText;
    }
    if (textType === "translation" && tradition.curatorNotes?.englishTranslation) {
      return tradition.curatorNotes.englishTranslation;
    }
    if (tradition.curatorNotes?.summary) {
      return tradition.curatorNotes.summary;
    }
    if (tradition.curatorNotes?.englishTranslation) {
      return tradition.curatorNotes.englishTranslation;
    }
    return tradition.originalText;
  }

  /**
   * Play AI Voice Narration for a tradition
   */
  public async play(
    tradition: Tradition,
    options?: {
      voiceId?: string;
      textType?: "summary" | "translation" | "original";
    }
  ): Promise<void> {
    if (!this.audio) {
      this.initAudioElement();
    }
    if (!this.audio) return;

    const voiceId = options?.voiceId || this.state.voiceId;
    const text = this.getNarrationText(tradition, options?.textType);
    const customKey = this.getCustomApiKey();

    if (this.state.traditionId === tradition.id && !this.state.error) {
      if (this.audio.paused) {
        try {
          await this.audio.play();
          this.updateState({ isPlaying: true });
        } catch (e: any) {
          console.error("Audio resume error:", e);
        }
      }
      return;
    }

    this.stop();

    const selectedVoiceObj = this.availableVoices.find((v) => v.id === voiceId);
    this.updateState({
      isLoading: true,
      isPlaying: false,
      traditionId: tradition.id,
      traditionTitle: tradition.title,
      currentTime: 0,
      duration: 0,
      voiceId,
      voiceName: selectedVoiceObj ? selectedVoiceObj.name : "AI Storyteller",
      engine: "gemini",
      error: null,
    });

    try {
      const params = new URLSearchParams();
      params.set("id", tradition.id);
      params.set("voiceId", voiceId);
      if (options?.textType) {
        params.set("type", options.textType);
      }
      if (customKey) {
        params.set("customKey", customKey);
      }

      const streamUrl = `/api/voice/stream?${params.toString()}`;
      this.audio.src = streamUrl;
      this.audio.playbackRate = this.playbackRate;
      this.audio.load();

      const playPromise = this.audio.play();
      if (playPromise !== undefined) {
        await playPromise;
        if (this.audio) this.audio.playbackRate = this.playbackRate;
        this.updateState({ isPlaying: true, isLoading: false });
      }
    } catch (err: any) {
      console.warn("Server stream unavailable, falling back to human speech synthesis:", err);
      // Seamless fallback to human speech synthesis
      this.playHumanNarration(
        text,
        tradition.language || "hindi",
        tradition.id,
        tradition.title,
        "all"
      );
    }
  }

  public pause() {
    if (this.synthUtterance && typeof window !== "undefined" && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      this.updateState({ isPlaying: false });
      return;
    }
    if (this.audio && !this.audio.paused) {
      this.audio.pause();
      this.updateState({ isPlaying: false });
    }
  }

  public resume() {
    if (this.synthUtterance && typeof window !== "undefined" && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      this.updateState({ isPlaying: true });
      return;
    }
    if (this.audio && this.audio.paused) {
      this.audio.play().catch((err) => {
        console.error("Resume error:", err);
      });
    }
  }

  public stop() {
    this.isSpeakingHuman = false;
    if (this.sentencePauseTimer) {
      clearTimeout(this.sentencePauseTimer);
      this.sentencePauseTimer = null;
    }
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      this.synthUtterance = null;
    }
    if (this.audio) {
      this.audio.pause();
      this.audio.currentTime = 0;
      this.audio.src = "";
    }
    this.updateState({
      isPlaying: false,
      isLoading: false,
      traditionId: null,
      traditionTitle: null,
      currentTime: 0,
      duration: 0,
      error: null,
      currentSpokenSentence: null,
    });
  }

  public seek(seconds: number) {
    if (this.audio && !isNaN(seconds)) {
      this.audio.currentTime = Math.max(0, Math.min(seconds, this.audio.duration || seconds));
    }
  }

  /**
   * Play regional language narration for a tradition (Hindi, Bhojpuri, Kashmiri, Nagpuri, English, etc.)
   */
  public async playRegional(
    tradition: Tradition,
    lang = "hindi",
    part: "all" | "caption" | "description" = "all"
  ): Promise<void> {
    if (!this.audio) {
      this.initAudioElement();
    }
    if (!this.audio) return;

    this.stop();

    this.updateState({
      isLoading: true,
      isPlaying: false,
      traditionId: tradition.id,
      traditionTitle: `${tradition.title} (${lang})`,
      currentTime: 0,
      duration: 0,
      language: lang,
      activePart: part,
      error: null,
    });

    try {
      const streamUrl = `/api/voice/regional-audio?id=${encodeURIComponent(tradition.id)}&lang=${encodeURIComponent(lang)}&part=${encodeURIComponent(part)}`;
      this.audio.src = streamUrl;
      this.audio.playbackRate = this.playbackRate;
      this.audio.load();

      const playPromise = this.audio.play();
      if (playPromise !== undefined) {
        await playPromise;
        if (this.audio) this.audio.playbackRate = this.playbackRate;
        this.updateState({ isPlaying: true, isLoading: false, engine: "gemini" });
      }
    } catch (err: any) {
      console.warn("Direct stream failed, falling back to speech synthesis:", err);
      // Fetch text and narrate with human speech synthesis
      try {
        const res = await fetch(`/api/voice/regional-narration?id=${encodeURIComponent(tradition.id)}&lang=${encodeURIComponent(lang)}`);
        if (res.ok) {
          const data = await res.json();
          let spokenText = data.fullText;
          if (part === "caption") spokenText = data.caption;
          if (part === "description") spokenText = data.description;
          await this.playHumanNarration(spokenText, lang, tradition.id, tradition.title, part);
        }
      } catch (innerErr) {
        this.updateState({
          isLoading: false,
          isPlaying: false,
          error: "Regional audio narration unavailable.",
        });
      }
    }
  }

  public async toggle(
    tradition: Tradition,
    options?: {
      voiceId?: string;
      textType?: "summary" | "translation" | "original";
    }
  ): Promise<void> {
    if (this.state.traditionId === tradition.id && this.state.isPlaying) {
      this.pause();
    } else {
      await this.play(tradition, options);
    }
  }
}

export const voiceService = new VoiceService();
