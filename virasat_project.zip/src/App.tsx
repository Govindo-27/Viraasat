import React, { useState, useEffect, useCallback } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { ArchiveGrid } from "./components/ArchiveGrid";
import { PreserveForm } from "./components/PreserveForm";
import { AskArchive } from "./components/AskArchive";
import { TraditionDetailModal } from "./components/TraditionDetailModal";
import { AboutModal } from "./components/AboutModal";
import { StaticDemoExportModal } from "./components/StaticDemoExportModal";
import { Footer } from "./components/Footer";
import { Tradition, HeritageCategory } from "./types";

const FALLBACK_SEEDS: Tradition[] = [
  {
    id: "VIR-2026-001",
    title: "The Song of the Kutch Monsoon Weavers (Kachchhi Megh Raga)",
    category: "Oral Histories",
    language: "Kachchhi (Gujarati script)",
    region: "Bhujodi, Kutch, Gujarat",
    contributorName: "Devji Vankar (Community Archivist)",
    datePreserved: "2026-10-14",
    originalText:
      "જ્યારે અષાઢી વાદળ રણની માથે ઘેરાય છે, ત્યારે અમારા વણકરો ખડ્ડી ઉપર ચરખો થંભાવીને મેઘ-રાગ આલાપે છે. આ ગીત માત્ર ધૂન નથી, પણ ઊનની તાર ખેંચવાની ગણતરી છે. દાદા કહેતા કે એક આલાપ એટલે બે આંટી, અને ત્રીજા ઢાળે કાંટાળી બાવળની છાલનો કુદરતી કથ્થઈ રંગ કાપડમાં ઉતારવો. વરસાદ આવે ત્યારે કાળી માટીની સુગંધ સાથે તારનું તણાવ બદલાય છે. જે વણકર આ ગીત ભૂલે છે, તેની શાલમાં વરસાદી ભેજ ટકતો નથી. આ પરંપરા ત્રણસો વર્ષથી માત્ર મુખપાઠ દ્વારા જ દીકરાઓને શીખવવામાં આવે છે.",
    consentGiven: true,
    verifiedStatus: "Unverified Community Contribution",
    curatorNotes: {
      summary:
        "An oral mnemonic song sung by master weavers in Bhujodi during the arrival of Ashadha monsoon clouds. The rhythmic verse encodes yarn tension measurements and the boiling duration for wild acacia bark dyes without written notations.",
      tags: ["Weaving Mnemonic", "Kutch Handloom", "Natural Acacia Dye", "Monsoon Traditions", "Oral Heritage"],
      englishTranslation:
        "When the monsoon clouds of Ashadha gather over the white salt desert, our weavers pause the wheel upon the pit loom and sing the Megh Raga. This verse is not merely music; it is the mathematical calculation for drawing the raw indigenous wool threads. My grandfather taught us that one melodic glide corresponds to two shuttle passes, and the cadence of the third descent dictates when to infuse the cloth with natural brown dye extracted from the bark of thorny acacia. As the rain nears, the black soil aroma signals a shift in warp tension. Any artisan who forgets this oral song produces shawls that absorb desert dampness. For three centuries, this rhythm has survived solely through father-to-son spoken recitation.",
      generatedAt: "2026-10-15T08:14:00Z",
      model: "Virasat AI Heritage Curator",
      isAiCurated: true,
    },
  },
  {
    id: "VIR-2026-002",
    title: "Neer-Kattai: Granite Sluice Protectors of the Kaveri Delta",
    category: "Folk Practices",
    language: "Tamil",
    region: "Thiruvaiyaru, Thanjavur, Tamil Nadu",
    contributorName: "Meenakshi Sundaram (Delta Farmer)",
    datePreserved: "2026-10-18",
    originalText:
      "எங்கள் சோழ மண்டலத்து வாய்க்கால்களில் நீர் திறக்கும் முன், 'நீர்க் கட்டை' எனப்படும் செதுக்கப்படாத கருங்கல் தூணில் வேப்பிலைக் காப்பு கட்டுவது வழக்கம். ஆடி பதினெட்டுப் பெருக்கில் ஆற்றில் புதிய நீர் வரும்போது, சேறு மூழ்காமல் இருக்க மணல் படுகையின் அசைவை முதியவர்கள் இந்த கல் மூழ்கும் அளவைக் கொண்டே கணிப்பார்கள். கல் பாதி மூழ்கினால் மட்டுமே நெல் வயல்களுக்கு நீரைத் திருப்புவோம். முழுதும் மூழ்கினால் வரப்பு உடையும் அபாயம் என ஊர் கூடி மதகை மூடுவர். நவீன மதகுகள் வந்தாலும், எங்கள் ஊர் மக்கள் இன்றும் அந்த பழைமையான கல்லை வணங்கி, நீர் கணக்கை அதன் நிழலிலேயே அளக்கிறார்கள்.",
    consentGiven: true,
    verifiedStatus: "Unverified Community Contribution",
    curatorNotes: {
      summary:
        "A traditional ecological hydrology practice from the Kaveri delta where uncut granite markers ('Neer-Kattai') draped with neem foliage are used as visual gauges to assess river sediment flow and regulate irrigation sluice openings during seasonal floods.",
      tags: ["Water Stewardship", "Kaveri Delta", "Folk Hydrology", "Aadi Perukku", "Traditional Ecology"],
      englishTranslation:
        "Before releasing water into our Chola-era distributary channels, it has been our custom to bind protective sprigs of neem leaves around an uncut black granite pillar known as the 'Neer-Kattai'. When fresh floodwaters swell the river during the monsoon festival of Aadi Perukku, village elders gauge the underwater silt movement by observing how deeply this stone is submerged. If the stone is half-covered, it is safe to divert water into the paddy fields. If the pillar is fully drowned, it warns of embankment breach, and the entire hamlet gathers to seal the wooden sluice. Although modern concrete regulators exist today, our elders still revere this stone indicator, reading water levels through its seasonal shadow.",
      generatedAt: "2026-10-18T11:20:00Z",
      model: "Virasat AI Heritage Curator",
      isAiCurated: true,
    },
  },
  {
    id: "VIR-2026-003",
    title: "Dhunachi Naach: Clay Censer Fire Rhythm of Kumartuli",
    category: "Festivals",
    language: "Bengali",
    region: "Kumartuli, Kolkata, West Bengal",
    contributorName: "Anirban Bhattacharya (Clay Artisan)",
    datePreserved: "2026-10-21",
    originalText:
      "কুমারটুলির প্রতিমা গড়ার কর্মশালায় বিজয়া দশমীর সন্ধ্যায় পোড়ামাটির ধুনুচি জ্বালানোর একটি নিজস্ব নিয়ম আছে। নারকেলের শুকনো ছোবড়া, শালগাছের খাঁটি ধুনো আর অল্প কর্পূরের গুঁড়ো সমান অনুপাতে পাত্রে রাখতে হয়। ঢাকের বোলের সাথে তাল মিলিয়ে এক পায়ে দাঁড়িয়ে ধুনুচি ওপরে তোলার সময় হাতের তালু যাতে পুড়ে না যায়, সেজন্য ধুনুচির নিচের সরু ডাঁটিতে ভিজা সুতি কাপড়ের টুকরো বাঁধা হয়। এটি কেবল কোনো নাচ নয়; এটি মাটির প্রতিমা তৈরির পর শিল্পীদের আশীর্বাদ চাওয়া এবং আগুনের পবিত্র শিখায় সমগ্র পল্লীর রোগ-বালাই দূর করার এক যৌথ প্রার্থনা।",
    consentGiven: true,
    verifiedStatus: "Unverified Community Contribution",
    curatorNotes: {
      summary:
        "A ritual fire censer dance maintained by terracotta idol sculptors in Kumartuli, combining precise ratios of coconut husk, sal tree resin, and camphor with balanced single-leg footwork synchronized with dhak drumming.",
      tags: ["Dhunachi", "Kumartuli Artisans", "Durga Puja Rites", "Terracotta Craft", "Bengali Folk Rhythms"],
      englishTranslation:
        "In the clay modeling workshops of Kumartuli on the eve of Vijaya Dashami, there is a distinct generational rule for lighting the terracotta dhunachi censer. Dried coconut husk fibers, pure fragrant sal tree resin (dhuno), and a measure of camphor powder must be layered in balanced proportions. As performers balance the burning clay vessel on one palm or between teeth to the complex polyrhythms of the dhak drum, a damp strip of khadi cloth is bound around the narrow stem to insulate the bearer's skin. This is not simply a festive dance; it is an offering of thanksgiving by the idol sculptors upon completing weeks of sacred clay modeling, believing the purifying smoke cleanses the neighborhood of disease and misfortune.",
      generatedAt: "2026-10-21T14:45:00Z",
      model: "Virasat AI Heritage Curator",
      isAiCurated: true,
    },
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<"archive" | "preserve" | "ask">("archive");
  const [traditions, setTraditions] = useState<Tradition[]>(FALLBACK_SEEDS);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<HeritageCategory>("All");
  const [selectedLanguage, setSelectedLanguage] = useState("All");

  // Modals
  const [selectedTradition, setSelectedTradition] = useState<Tradition | null>(null);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const fetchTraditions = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery.trim()) params.append("q", searchQuery.trim());
      if (selectedCategory !== "All") params.append("category", selectedCategory);
      if (selectedLanguage !== "All") params.append("language", selectedLanguage);

      const res = await fetch(`/api/contributions?${params.toString()}`);
      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.data) && json.data.length > 0) {
          setTraditions(json.data);
        } else if (searchQuery.trim() || selectedCategory !== "All" || selectedLanguage !== "All") {
          setTraditions([]);
        }
      }
    } catch (err) {
      console.warn("API request failed, filtering local dataset:", err);
      let filtered = [...FALLBACK_SEEDS];
      if (selectedCategory !== "All") {
        filtered = filtered.filter((t) => t.category.toLowerCase() === selectedCategory.toLowerCase());
      }
      if (selectedLanguage !== "All") {
        filtered = filtered.filter((t) => t.language.toLowerCase().includes(selectedLanguage.toLowerCase()));
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        filtered = filtered.filter(
          (t) =>
            t.title.toLowerCase().includes(q) ||
            t.region.toLowerCase().includes(q) ||
            t.originalText.toLowerCase().includes(q) ||
            t.curatorNotes?.summary?.toLowerCase().includes(q)
        );
      }
      setTraditions(filtered);
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery, selectedCategory, selectedLanguage]);

  useEffect(() => {
    fetchTraditions();
  }, [fetchTraditions]);

  const handleSelectTraditionById = (id: string) => {
    const match = traditions.find((t) => t.id === id) || FALLBACK_SEEDS.find((t) => t.id === id);
    if (match) {
      setSelectedTradition(match);
    }
  };

  const handlePreserveSuccess = (newTradition: Tradition) => {
    setTraditions((prev) => [newTradition, ...prev]);
    setActiveTab("archive");
    setSelectedTradition(newTradition);
    window.scrollTo({ top: 380, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#22201D] flex flex-col font-sans">
      {/* 1. Header with all navigation links */}
      <Header
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: tab === "archive" ? 0 : 200, behavior: "smooth" });
        }}
        onOpenAbout={() => setIsAboutModalOpen(true)}
        onOpenExportGuide={() => setIsExportModalOpen(true)}
      />

      {/* 2. Hero Section */}
      <Hero
        traditionsCount={traditions.length}
        onNavigateToArchive={() => {
          setActiveTab("archive");
          const el = document.getElementById("archive-section");
          el?.scrollIntoView({ behavior: "smooth" });
        }}
        onNavigateToPreserve={() => {
          setActiveTab("preserve");
          window.scrollTo({ top: 180, behavior: "smooth" });
        }}
        onNavigateToAsk={() => {
          setActiveTab("ask");
          window.scrollTo({ top: 180, behavior: "smooth" });
        }}
      />

      {/* 3. Main Content Views */}
      <main key={activeTab} className="flex-1 animate-fade-in" id="archive-section">
        {activeTab === "archive" && (
          <ArchiveGrid
            traditions={traditions}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            selectedLanguage={selectedLanguage}
            onLanguageChange={setSelectedLanguage}
            onSelectTradition={setSelectedTradition}
            isLoading={isLoading}
          />
        )}

        {activeTab === "preserve" && (
          <PreserveForm
            onSuccess={handlePreserveSuccess}
            onCancel={() => setActiveTab("archive")}
          />
        )}

        {activeTab === "ask" && (
          <AskArchive
            traditions={traditions}
            onSelectTraditionById={handleSelectTraditionById}
          />
        )}
      </main>

      {/* 4. Modals */}
      <TraditionDetailModal
        tradition={selectedTradition}
        onClose={() => setSelectedTradition(null)}
      />

      {isAboutModalOpen && (
        <AboutModal
          traditionsCount={traditions.length}
          onClose={() => setIsAboutModalOpen(false)}
        />
      )}

      {isExportModalOpen && (
        <StaticDemoExportModal
          traditions={traditions}
          onClose={() => setIsExportModalOpen(false)}
        />
      )}

      {/* 5. Footer */}
      <Footer
        onOpenAbout={() => setIsAboutModalOpen(true)}
        onOpenExportGuide={() => setIsExportModalOpen(true)}
        onTabChange={setActiveTab}
      />
    </div>
  );
}
